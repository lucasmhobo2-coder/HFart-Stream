import React, { useState, useEffect } from 'react';
import { ViewMode, Stream, Creator, UserProfile } from './types';
import { 
  INITIAL_STREAMS, INITIAL_CREATORS, INITIAL_CLIPS, INITIAL_RECORDINGS, INITIAL_POSTS, MOCK_AD_CAMPAIGNS, MOCK_CREATOR_ANALYTICS 
} from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { CreateModal } from './components/CreateModal';
import { HomeScreen } from './components/HomeScreen';
import { DiscoverScreen } from './components/DiscoverScreen';
import { LiveWatchScreen } from './components/LiveWatchScreen';
import { GoLiveSetupScreen } from './components/GoLiveSetupScreen';
import { CreatorWhileLiveScreen } from './components/CreatorWhileLiveScreen';
import { CreatorDashboard } from './components/CreatorDashboard';
import { UserProfileScreen } from './components/UserProfileScreen';
import { AdminDashboard } from './components/AdminDashboard';
import { BusinessCenterScreen } from './components/BusinessCenterScreen';
import { DeveloperPortalScreen } from './components/DeveloperPortalScreen';
import { SplashScreen } from './components/SplashScreen';
import { AuthModal } from './components/AuthModal';
import { NotificationsModal } from './components/NotificationsModal';
import { subscribeToAuth, logoutUser } from './lib/authService';
import { 
  seedFirestoreIfEmpty, subscribeToStreams, subscribeToCreators, createFirestoreStream, toggleFollowFirestoreCreator, updateFirestoreStream, notifyFollowersStreamLive 
} from './lib/firestoreService';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const [viewMode, setViewMode] = useState<ViewMode>('home');
  const [streams, setStreams] = useState<Stream[]>(INITIAL_STREAMS);
  const [creators, setCreators] = useState<Creator[]>(INITIAL_CREATORS);
  const [selectedStream, setSelectedStream] = useState<Stream>(INITIAL_STREAMS[0]);
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>('c1');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Seed Firestore and listen to auth & real-time Firestore data
  useEffect(() => {
    seedFirestoreIfEmpty();

    const unsubAuth = subscribeToAuth((user) => {
      setCurrentUser(user);
    });

    const unsubStreams = subscribeToStreams((fireStreams) => {
      if (fireStreams && fireStreams.length > 0) {
        setStreams(fireStreams);
      }
    });

    const unsubCreators = subscribeToCreators((fireCreators) => {
      if (fireCreators && fireCreators.length > 0) {
        setCreators(fireCreators);
      }
    });

    return () => {
      unsubAuth();
      unsubStreams();
      unsubCreators();
    };
  }, []);

  // Splash Screen timer dismissal
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  // Current user's creator profile
  const currentCreator = creators[0];

  // Login handler from AuthModal
  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    setIsAuthModalOpen(false);
  };

  // Follow/Unfollow toggle
  const handleToggleFollow = (creatorId: string) => {
    setCreators((prevCreators) =>
      prevCreators.map((c) => {
        if (c.id === creatorId) {
          const isNowFollowing = !c.isFollowing;
          return {
            ...c,
            isFollowing: isNowFollowing,
            followersCount: isNowFollowing ? c.followersCount + 1 : c.followersCount - 1,
          };
        }
        return c;
      })
    );

    // Sync stream creators
    setStreams((prevStreams) =>
      prevStreams.map((s) => {
        if (s.creator.id === creatorId) {
          const isNowFollowing = !s.creator.isFollowing;
          return {
            ...s,
            creator: {
              ...s.creator,
              isFollowing: isNowFollowing,
              followersCount: isNowFollowing ? s.creator.followersCount + 1 : s.creator.followersCount - 1,
            },
          };
        }
        return s;
      })
    );
  };

  // Subscribe toggle
  const handleToggleSubscribe = (creatorId: string) => {
    setCreators((prevCreators) =>
      prevCreators.map((c) => (c.id === creatorId ? { ...c, isSubscribed: !c.isSubscribed } : c))
    );

    setStreams((prevStreams) =>
      prevStreams.map((s) =>
        s.creator.id === creatorId
          ? { ...s, creator: { ...s.creator, isSubscribed: !s.creator.isSubscribed } }
          : s
      )
    );
  };

  // Select stream to watch
  const handleSelectStream = (stream: Stream) => {
    setSelectedStream(stream);
    setViewMode('live_watch');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Select creator to view profile
  const handleSelectCreator = (creatorId: string) => {
    setSelectedCreatorId(creatorId);
    setViewMode('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Start new stream from GoLiveSetup
  const handleStartLiveStream = async (newStreamData: Partial<Stream>) => {
    const creatorToUse: Creator = currentCreator || {
      id: currentUser?.id || 'c_me',
      name: currentUser?.fullName || 'HFArt Creator',
      username: currentUser?.username || 'creator_live',
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      banner: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80',
      verified: true,
      isLive: true,
      followersCount: 1200,
      followingCount: 45,
      totalLikes: 3400,
      totalViews: 18200,
      bio: 'Streaming live on HFArt platform.',
      isFollowing: false,
      isSubscribed: false,
    };

    const newStreamObject: Omit<Stream, 'id'> = {
      title: newStreamData.title || 'My Live Stream',
      description: newStreamData.description || 'Welcome to my live broadcast on HFArt!',
      category: newStreamData.category || 'Music',
      creator: { ...creatorToUse, isLive: true },
      thumbnail: newStreamData.thumbnail || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
      viewerCount: 1,
      likesCount: 0,
      startedAt: 'Just now',
      isLive: true,
      tags: newStreamData.tags || ['LiveStream', 'HFArt'],
      visibility: newStreamData.visibility || 'Public',
      allowClips: newStreamData.allowClips ?? true,
      enableChat: newStreamData.enableChat ?? true,
      recordStream: newStreamData.recordStream ?? true,
    };

    try {
      const realStreamId = await createFirestoreStream(newStreamObject);
      await notifyFollowersStreamLive(creatorToUse.name, newStreamObject.title, realStreamId, creatorToUse.avatar);
      const fullStream: Stream = { id: realStreamId, ...newStreamObject };
      setSelectedStream(fullStream);
      setViewMode('while_live_creator');
    } catch (err) {
      console.error('Error creating stream in Firestore:', err);
      const fallbackStream: Stream = { id: `str-${Date.now()}`, ...newStreamObject };
      setSelectedStream(fallbackStream);
      setViewMode('while_live_creator');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // End creator stream
  const handleEndStream = () => {
    if (selectedStream?.id) {
      updateFirestoreStream(selectedStream.id, { isLive: false });
    }
    setStreams((prev) =>
      prev.map((s) => (s.id === selectedStream.id ? { ...s, isLive: false } : s))
    );
    setViewMode('creator_studio');
  };

  const currentProfileCreator = creators.find((c) => c.id === selectedCreatorId) || currentCreator;

  return (
    <div id="hfart-app-root" className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-red-600 selection:text-white flex flex-col">
      
      {/* Animated Splash Screen */}
      {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} onFinish={() => setShowSplash(false)} />}

      {/* Top Header */}
      <Header
        viewMode={viewMode}
        setViewMode={setViewMode}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        currentCreator={currentCreator}
        currentUser={currentUser}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
        onOpenNotificationsModal={() => setIsNotificationsModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main View Area */}
      <main id="app-main-viewport" className="flex-1 w-full max-w-7xl mx-auto pt-4">
        
        {/* View Mode Router */}
        {viewMode === 'home' && (
          <HomeScreen
            streams={streams}
            onSelectStream={handleSelectStream}
            onToggleFollow={handleToggleFollow}
            onSelectCreator={handleSelectCreator}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {viewMode === 'discover' && (
          <DiscoverScreen
            streams={streams}
            clips={INITIAL_CLIPS}
            creators={creators}
            onSelectStream={handleSelectStream}
            onSelectCreator={handleSelectCreator}
            onToggleFollow={handleToggleFollow}
          />
        )}

        {viewMode === 'live_watch' && (
          <LiveWatchScreen
            stream={selectedStream}
            onToggleFollow={handleToggleFollow}
            onToggleSubscribe={handleToggleSubscribe}
            onSelectCreator={handleSelectCreator}
          />
        )}

        {viewMode === 'go_live_setup' && (
          <GoLiveSetupScreen
            currentCreator={currentCreator}
            onStartLiveStream={handleStartLiveStream}
          />
        )}

        {viewMode === 'while_live_creator' && (
          <CreatorWhileLiveScreen
            stream={selectedStream}
            onEndStream={handleEndStream}
          />
        )}

        {viewMode === 'creator_studio' && (
          <CreatorDashboard
            creator={currentCreator}
            analytics={MOCK_CREATOR_ANALYTICS}
            setViewMode={setViewMode}
          />
        )}

        {viewMode === 'profile' && (
          <UserProfileScreen
            creator={currentProfileCreator}
            streams={streams}
            recordings={INITIAL_RECORDINGS}
            clips={INITIAL_CLIPS}
            posts={INITIAL_POSTS}
            onToggleFollow={handleToggleFollow}
            onToggleSubscribe={handleToggleSubscribe}
            onSelectStream={handleSelectStream}
          />
        )}

        {viewMode === 'admin_dashboard' && (
          <AdminDashboard
            streams={streams}
            creators={creators}
            adCampaigns={MOCK_AD_CAMPAIGNS}
          />
        )}

        {viewMode === 'business_center' && (
          <BusinessCenterScreen
            creators={creators}
            adCampaigns={MOCK_AD_CAMPAIGNS}
          />
        )}

        {viewMode === 'developer_portal' && (
          <DeveloperPortalScreen />
        )}

      </main>

      {/* Create Modal Drawer */}
      <CreateModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        setViewMode={setViewMode}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsModalOpen}
        onClose={() => setIsNotificationsModalOpen(false)}
      />

      {/* Bottom Navigation */}
      <BottomNav
        viewMode={viewMode}
        setViewMode={setViewMode}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
      />

    </div>
  );
}
