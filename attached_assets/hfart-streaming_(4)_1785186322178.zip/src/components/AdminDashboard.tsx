import React, { useState } from 'react';
import { 
  Shield, Users, UserCheck, Radio, Flag, Layers, DollarSign, Sparkles, Sliders, Key, Terminal, Map, TrendingUp, CheckCircle, AlertTriangle, Play, Settings, Activity, Cpu, HardDrive, Server, Workflow, RefreshCw, Database, Lock, Smartphone, AlertCircle, CheckCircle2, Zap, GitPullRequest, Globe, SlidersHorizontal, FileText, ArrowRight, Bot
} from 'lucide-react';
import { Stream, Creator, AdCampaign } from '../types';

interface AdminDashboardProps {
  streams: Stream[];
  creators: Creator[];
  adCampaigns: AdCampaign[];
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  streams,
  creators,
  adCampaigns,
}) => {
  const [activeTab, setActiveTab] = useState<
    'hoc' | 'dashboard' | 'settings' | 'organizations' | 'creator_levels' | 'pipeline' | 'services' | 'servers' | 'rollout' | 'backups' | 'developer' | 'business' | 'users' | 'creators' | 'streams' | 'reports' | 'categories' | 'revenue' | 'ads' | 'logs' | 'roadmap'
  >('hoc');

  // Enterprise Platform Settings State
  const [userRegistrationMode, setUserRegistrationMode] = useState<'Open' | 'Invite-Only' | 'Closed'>('Open');
  const [maintenanceMode, setMaintenanceMode] = useState<boolean>(false);
  const [aiModerationSensitivity, setAiModerationSensitivity] = useState<'Strict' | 'Balanced' | 'Relaxed'>('Balanced');
  const [payoutThreshold, setPayoutThreshold] = useState<number>(50);
  const [adFrequencyPolicy, setAdFrequencyPolicy] = useState<'Standard (2/hr)' | 'Aggressive (4/hr)' | 'Minimal (1/hr)'>('Standard (2/hr)');

  // Organization Accounts
  const [orgAccounts, setOrgAccounts] = useState([
    { id: 'org-1', name: 'University of Cape Town', type: 'University', verified: true, admins: ['dr_moyo@uct.ac.za', 'admin@uct.ac.za'], membersCount: 1420 },
    { id: 'org-2', name: 'Grace Faith Community Church', type: 'Church', verified: true, admins: ['pastor_david@grace.org'], membersCount: 850 },
    { id: 'org-3', name: 'Soweto Youth Sports Club', type: 'Sports Club', verified: true, admins: ['coach_sipho@sowetosports.org'], membersCount: 620 },
    { id: 'org-4', name: 'Gauteng Dept of Arts & Culture', type: 'Government', verified: true, admins: ['media@gauteng.gov.za'], membersCount: 3400 },
  ]);

  // HOC State Controls
  const [serverALoad, setServerALoad] = useState<number>(88);
  const [serverBLoad, setServerBLoad] = useState<number>(24);
  const [failoverActive, setFailoverActive] = useState<boolean>(false);

  // Staged Rollout State
  const [rolloutPercentage, setRolloutPercentage] = useState<number>(25);

  // Disaster Recovery State
  const [lastBackupTime, setLastBackupTime] = useState<string>('12 minutes ago');
  const [isBackupRunning, setIsBackupRunning] = useState<boolean>(false);

  // Moderation Queue State
  const [reportsQueue, setReportsQueue] = useState([
    { id: 'rep-101', user: '@troll_master', reporter: '@alex_vibe', reason: 'Spamming abusive chat links', stream: 'Soweto Music Fest Live', severity: 'High', status: 'Pending' },
    { id: 'rep-102', user: '@crypto_bot', reporter: '@cyber_knight', reason: 'Unsolicited scam link in stream chat', stream: 'Cyberpunk Gaming Night', severity: 'Medium', status: 'Pending' },
    { id: 'rep-[103]', user: '@loud_fan', reporter: '@maria_music', reason: 'Copyright audio infringement claim', stream: 'Acoustic Guitar Session', severity: 'Low', status: 'Pending' },
  ]);

  const adminNav = [
    { id: 'hoc', label: '🟢 Operations Center (HOC)', icon: Activity },
    { id: 'settings', label: 'Platform Settings', icon: Settings },
    { id: 'creator_levels', label: 'Creator Levels & Unlocks', icon: TrendingUp },
    { id: 'organizations', label: 'Organization Accounts', icon: Users },
    { id: 'dashboard', label: 'Overview Metrics', icon: Shield },
    { id: 'pipeline', label: 'Live Stream Pipeline', icon: Workflow },
    { id: 'services', label: 'Microservices Mesh', icon: Layers },
    { id: 'servers', label: 'Server Monitoring', icon: Server },
    { id: 'rollout', label: 'Staged Rollout', icon: GitPullRequest },
    { id: 'backups', label: 'Disaster Recovery', icon: Database },
    { id: 'developer', label: 'Developer Portal', icon: Key },
    { id: 'business', label: 'Business Portal', icon: Sparkles },
    { id: 'reports', label: 'Moderation & AI Queue', icon: Flag },
    { id: 'users', label: 'Users Directory', icon: Users },
    { id: 'creators', label: 'Creators Directory', icon: UserCheck },
    { id: 'streams', label: 'Live Broadcasts', icon: Radio },
    { id: 'revenue', label: 'Revenue Ledger', icon: DollarSign },
    { id: 'ads', label: 'HV100 Ads Network', icon: Sparkles },
    { id: 'logs', label: 'System Logs', icon: Terminal },
    { id: 'roadmap', label: 'Platform Roadmap', icon: Map },
  ];

  return (
    <div id="admin-dashboard-container" className="px-4 sm:px-6 py-6 pb-24 max-w-7xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-600 via-red-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-rose-950/60">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-white">HFArt Admin Control Panel</h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 font-semibold border border-rose-800">
                Superadmin
              </span>
            </div>
            <p className="text-xs text-slate-400">Platform owner management & HV100 ad network oversight</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-emerald-400 font-mono flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            Cloud Run Cluster: 100% Healthy
          </div>
        </div>
      </div>

      {/* Admin Sub-Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar border-b border-slate-800">
        {adminNav.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab: HFArt Operations Center (HOC) */}
      {activeTab === 'hoc' && (
        <div className="space-y-6 text-xs">
          {/* Top HOC Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                  <h2 className="text-lg font-extrabold text-white">HFArt Operations Center (HOC)</h2>
                </div>
                <p className="text-slate-400 mt-0.5">Real-time internal control operations center for platform owners</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setServerALoad(serverALoad > 80 ? 35 : 92);
                    if (serverALoad > 80) setFailoverActive(true);
                  }}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold border border-slate-700 transition-all flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Simulate Load Spike</span>
                </button>
                <button
                  onClick={() => setFailoverActive(!failoverActive)}
                  className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                    failoverActive ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white hover:bg-red-500'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{failoverActive ? 'Failover Active (Traffic Routed to Server B)' : 'Trigger Auto-Failover'}</span>
                </button>
              </div>
            </div>

            {/* HOC Top Metric Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 pt-2">
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Platform Status</span>
                <span className="text-xs font-extrabold text-emerald-400">🟢 Operational</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Users Online</span>
                <span className="text-sm font-extrabold text-white">76,890</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Live Streams</span>
                <span className="text-sm font-extrabold text-white">{streams.length}</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Messages / Sec</span>
                <span className="text-sm font-extrabold text-emerald-400 font-mono">24.1k</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Active Countries</span>
                <span className="text-sm font-extrabold text-white">182</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Server Load</span>
                <span className={`text-sm font-extrabold font-mono ${serverALoad > 80 && !failoverActive ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`}>
                  {failoverActive ? '31% Avg' : `${serverALoad}%`}
                </span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">Alerts</span>
                <span className="text-sm font-extrabold text-emerald-400">0 Critical</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">DB Health</span>
                <span className="text-xs font-extrabold text-emerald-400 font-mono">14ms / 99.99%</span>
              </div>
            </div>
          </div>

          {/* Server Monitoring & Auto-Failover Logic Diagram */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-rose-500" />
                  Server Health & Failover Architecture
                </h3>
                <p className="text-slate-400">Automatic traffic re-routing protects user playback during peak load spikes</p>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${failoverActive ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'}`}>
                {failoverActive ? 'Failover Rerouting Enabled' : 'Load Balancing Balanced'}
              </span>
            </div>

            {/* Failover Diagram */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-center">
              <div className={`p-3 rounded-2xl border w-full md:w-1/4 transition-all ${serverALoad > 80 && !failoverActive ? 'bg-rose-950/60 border-rose-600 text-rose-300' : 'bg-slate-900 border-slate-800 text-slate-300'}`}>
                <span className="font-bold block text-sm">Server A (ZA Primary)</span>
                <span className="text-[10px] block mt-1">CPU: {serverALoad}% • Mem: 68%</span>
                <span className="text-[10px] font-mono text-slate-400">102.165.18.42</span>
              </div>

              <div className="flex flex-col items-center">
                <ArrowRight className={`w-5 h-5 ${failoverActive ? 'text-amber-400 animate-bounce' : 'text-slate-600'}`} />
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider my-0.5">
                  {failoverActive ? 'Auto-Rerouting Active' : 'Load Balancer'}
                </span>
                <ArrowRight className={`w-5 h-5 ${failoverActive ? 'text-amber-400 animate-bounce' : 'text-slate-600'}`} />
              </div>

              <div className={`p-3 rounded-2xl border w-full md:w-1/4 transition-all ${failoverActive ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-950' : 'bg-slate-900 border-slate-800 text-slate-300'}`}>
                <span className="font-bold block text-sm">Server B (EU Secondary)</span>
                <span className="text-[10px] block mt-1">CPU: {failoverActive ? '58%' : `${serverBLoad}%`} • Mem: 42%</span>
                <span className="text-[10px] font-mono text-slate-400">185.220.101.5</span>
              </div>

              <div className="flex flex-col items-center">
                <ArrowRight className="w-5 h-5 text-emerald-400" />
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider my-0.5">Zero Downtime</span>
                <ArrowRight className="w-5 h-5 text-emerald-400" />
              </div>

              <div className="p-3 rounded-2xl border border-emerald-800 bg-emerald-950/40 text-emerald-300 w-full md:w-1/4">
                <span className="font-bold block text-sm">Viewer Stream Playback</span>
                <span className="text-[10px] block mt-1">100% Buffer-Free Quality</span>
                <span className="text-[10px] font-mono text-emerald-400">1080p60 • 60 FPS</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Live Stream Pipeline */}
      {activeTab === 'pipeline' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Workflow className="w-5 h-5 text-rose-500" />
              Live Streaming Video Pipeline Architecture
            </h3>
            <p className="text-slate-400">From creator camera capture to multi-bitrate transcoding and CDN viewer delivery</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {[
              { step: '1. Creator Camera', desc: 'RTMP / WebRTC 1080p source video ingest', tag: 'Source Input' },
              { step: '2. Ingest Server', desc: 'Authentication, bitrate verification, buffer queue', tag: 'Edge Ingest' },
              { step: '3. Transcoding Engine', desc: 'Encodes 1080p (8Mbps), 720p (4Mbps), 480p (1.5Mbps)', tag: 'HLS / DASH' },
              { step: '4. Content Delivery', desc: 'Multi-region CDN caching & low-latency edge nodes', tag: 'Global CDN' },
              { step: '5. Viewers', desc: 'Adaptive bitrate playback across iOS, Android & Web', tag: 'End Devices' },
            ].map((p, idx) => (
              <div key={idx} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 relative">
                <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-extrabold text-[9px] uppercase tracking-wider border border-rose-800">
                  {p.tag}
                </span>
                <h4 className="font-bold text-white text-sm">{p.step}</h4>
                <p className="text-slate-400 text-[11px] leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
            <h4 className="font-bold text-white text-sm">Transcoding Quality Bitrates</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">1080p60 Ultra HD</span>
                  <span className="text-slate-400 text-[10px]">6000-8000 Kbps • High Bandwidth</span>
                </div>
                <span className="text-emerald-400 font-mono font-bold">Active</span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">720p60 HD Standard</span>
                  <span className="text-slate-400 text-[10px]">3000-4500 Kbps • Medium Bandwidth</span>
                </div>
                <span className="text-emerald-400 font-mono font-bold">Active</span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">480p Mobile Saver</span>
                  <span className="text-slate-400 text-[10px]">1000-1800 Kbps • Data Saving</span>
                </div>
                <span className="text-emerald-400 font-mono font-bold">Active</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Staged Rollout */}
      {activeTab === 'rollout' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <GitPullRequest className="w-5 h-5 text-rose-500" />
              Staged Release & Canary Deployment Rollout
            </h3>
            <p className="text-slate-400">Safely deploy new platform updates to small user percentage buckets before global release</p>
          </div>

          <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <span className="font-bold text-white text-sm">HFArt Platform Build v2.4.0 (Canary Release)</span>
                <p className="text-slate-400 text-[11px]">Includes new 4K streaming pipeline and low-latency audio sync</p>
              </div>
              <span className="px-3 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 font-extrabold rounded-full">
                Target Allocation: {rolloutPercentage}%
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-slate-400 font-bold text-[11px]">
                <span>5% Testing Bucket</span>
                <span>25% Early Audience</span>
                <span>50% Half Rollout</span>
                <span>100% Full Release</span>
              </div>
              <input
                type="range"
                min="5"
                max="100"
                step="5"
                value={rolloutPercentage}
                onChange={(e) => setRolloutPercentage(Number(e.target.value))}
                className="w-full accent-red-600 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
              {[
                { stage: '1. Internal Staging', status: 'Passed', color: 'text-emerald-400' },
                { stage: '2. Telemetry Check', status: 'Clean (0 Crashes)', color: 'text-emerald-400' },
                { stage: '3. Active Bucket', status: `${rolloutPercentage}% Users Allocated`, color: 'text-amber-400' },
                { stage: '4. Full Promotion', status: rolloutPercentage === 100 ? 'Live Globally' : 'Pending Allocation', color: rolloutPercentage === 100 ? 'text-emerald-400' : 'text-slate-400' },
              ].map((s, idx) => (
                <div key={idx} className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="font-bold text-white block">{s.stage}</span>
                  <span className={`text-[11px] font-semibold ${s.color}`}>{s.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Disaster Recovery */}
      {activeTab === 'backups' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-rose-500" />
                Disaster Recovery & Automated Backup Procedures
              </h3>
              <p className="text-slate-400">Point-in-time database snapshots, video storage mirrors and automated failover restores</p>
            </div>
            <button
              onClick={() => {
                setIsBackupRunning(true);
                setTimeout(() => {
                  setIsBackupRunning(false);
                  setLastBackupTime('Just now');
                }, 2000);
              }}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold transition-all shadow-md flex items-center gap-2"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isBackupRunning ? 'animate-spin' : ''}`} />
              <span>{isBackupRunning ? 'Creating Backup Snapshot...' : '+ Create On-Demand Backup Snapshot'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-white text-sm block">Firestore Database Backups</span>
              <p className="text-slate-400 text-[11px]">Automated point-in-time snapshots every 15 minutes</p>
              <div className="pt-2 flex justify-between font-mono text-[11px]">
                <span className="text-slate-500">Last Backup:</span>
                <span className="text-emerald-400 font-bold">{lastBackupTime}</span>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-white text-sm block">Media Storage Bucket Replication</span>
              <p className="text-slate-400 text-[11px]">Dual-region redundant VOD & thumbnail mirrors</p>
              <div className="pt-2 flex justify-between font-mono text-[11px]">
                <span className="text-slate-500">Status:</span>
                <span className="text-emerald-400 font-bold">100% Synced</span>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-bold text-white text-sm block">Configuration & Keys Restore</span>
              <p className="text-slate-400 text-[11px]">Encrypted KMS configuration backup vault</p>
              <div className="pt-2 flex justify-between font-mono text-[11px]">
                <span className="text-slate-500">Recovery RTO:</span>
                <span className="text-emerald-400 font-bold">&lt; 30 Seconds</span>
              </div>
            </div>
          </div>
        </div>
      )}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-xs text-slate-400 font-medium">Active Streams</span>
              <div className="flex items-baseline justify-between">
                <span className="text-xl font-bold text-white">{streams.length}</span>
                <span className="text-xs text-emerald-400 font-mono">100% Live</span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-xs text-slate-400 font-medium">Total Platform Viewers</span>
              <div className="flex items-baseline justify-between">
                <span className="text-xl font-bold text-white">76,890</span>
                <span className="text-xs text-emerald-400">+12% peak</span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-xs text-slate-400 font-medium">HV100 Ad Impressions</span>
              <div className="flex items-baseline justify-between">
                <span className="text-xl font-bold text-amber-400">1.37M</span>
                <span className="text-xs text-amber-300">$28.50 CPM</span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-xs text-slate-400 font-medium">Total Platform Revenue</span>
              <div className="flex items-baseline justify-between">
                <span className="text-xl font-bold text-emerald-400">$84,250</span>
                <span className="text-xs text-emerald-400">Jul 2026</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Active Broadcasts</h3>
              <div className="space-y-3">
                {streams.slice(0, 3).map((s) => (
                  <div key={s.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <h4 className="font-bold text-white">{s.title}</h4>
                      <p className="text-slate-400">{s.creator.name} • {s.viewerCount.toLocaleString()} Viewers</p>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-semibold text-[10px]">
                      Healthy
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Multi-Region Edge Nodes</h3>
              <div className="space-y-2 text-xs">
                {[
                  { region: 'Africa Server (ZA Primary)', location: 'Johannesburg / Cape Town', latency: '12ms', status: 'Optimal' },
                  { region: 'Europe Server (EU Edge)', location: 'Frankfurt / London', latency: '38ms', status: 'Optimal' },
                  { region: 'North America Server (US East)', location: 'Virginia / Oregon', latency: '82ms', status: 'Optimal' },
                  { region: 'Asia Server (APAC Cluster)', location: 'Singapore / Tokyo', latency: '108ms', status: 'Optimal' },
                  { region: 'Australia Server (Oceania Node)', location: 'Sydney', latency: '125ms', status: 'Optimal' },
                ].map((node, i) => (
                  <div key={i} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-white">{node.region}</span>
                      <p className="text-[10px] text-slate-400">{node.location}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-mono font-bold">{node.latency}</span>
                      <p className="text-[10px] text-emerald-500 font-semibold">{node.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Microservices Mesh */}
      {activeTab === 'services' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 text-xs">
          <div>
            <h3 className="text-base font-bold text-white">HFArt Cloud Microservices Architecture Status</h3>
            <p className="text-slate-400">Decoupled isolated services routed through API Gateway for zero-downtime resilience</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { name: 'API Gateway', role: 'Security verification, rate limiting, routing', status: 'Healthy', reqs: '12.4k req/sec' },
              { name: 'Authentication Service', role: 'OAuth tokens, JWT validation, security', status: 'Healthy', reqs: '1.2k req/sec' },
              { name: 'User Service', role: 'Profiles, preferences, follow lists', status: 'Healthy', reqs: '3.8k req/sec' },
              { name: 'Live Stream Service', role: 'RTMP ingestion, WebRTC encoding', status: 'Healthy', reqs: '8.5k req/sec' },
              { name: 'Chat Service', role: 'Real-time WebSockets, moderation filter', status: 'Healthy', reqs: '24.1k msgs/sec' },
              { name: 'Notification Service', role: 'Push notifications, follower alerts', status: 'Healthy', reqs: '4.5k/sec' },
              { name: 'Ads Service (HV100)', role: 'Ad break scheduler, impression logger', status: 'Healthy', reqs: '890 req/sec' },
              { name: 'Creator & Wallet Service', role: 'Monetization balances, payout provider', status: 'Healthy', reqs: '420 req/sec' },
              { name: 'Storage & Database Cluster', role: 'File storage bucket, replicated Firestore DB', status: 'Healthy', reqs: '99.99% Uptime' },
            ].map((svc, i) => (
              <div key={i} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">{svc.name}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold text-[10px]">
                    {svc.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px]">{svc.role}</p>
                <div className="pt-2 border-t border-slate-800/80 flex justify-between text-[11px]">
                  <span className="text-slate-500">Traffic Load:</span>
                  <span className="text-emerald-400 font-mono font-bold">{svc.reqs}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Developer Portal */}
      {activeTab === 'developer' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 text-xs">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white">HFArt Developer Platform Portal</h3>
              <p className="text-slate-400">API keys, Webhook subscriptions, Moderation bots & SDK downloads for third-party integrations</p>
            </div>
            <button className="px-4 py-2 rounded-xl bg-red-600 text-white font-bold text-xs">
              + Generate New API Key
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <h4 className="font-bold text-white">Active Developer Applications</h4>
              <div className="space-y-2">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-white">AutoMod Bot v2</span>
                    <p className="text-[10px] text-slate-400">Permissions: Chat Read/Write, Timeout Users</p>
                  </div>
                  <span className="text-emerald-400 font-mono font-bold">`hf_dev_982173981`</span>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-white">Stream Overlay Overlay Pro</span>
                    <p className="text-[10px] text-slate-400">Permissions: Read Live Stats, Donation Alerts</p>
                  </div>
                  <span className="text-emerald-400 font-mono font-bold">`hf_dev_102839102`</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <h4 className="font-bold text-white">SDK Downloads & Webhook Callbacks</h4>
              <div className="space-y-2">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span>TypeScript / Node.js SDK</span>
                  <button className="text-red-400 hover:underline font-bold">Download v1.4.0</button>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span>Python Stream Engine SDK</span>
                  <button className="text-red-400 hover:underline font-bold">Download v2.1.0</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Business Portal */}
      {activeTab === 'business' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 text-xs">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white">Business Advertising & Sponsorship Portal</h3>
              <p className="text-slate-400">Verified brand advertiser accounts, HV100 campaign budgets & creator sponsorship deals</p>
            </div>
            <button className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-extrabold text-xs">
              + Verify Advertiser Account
            </button>
          </div>

          <div className="space-y-3">
            {[
              { brand: 'CyberGear Audio Tech', campaign: 'HV100 Studio Headphones Launch', budget: '$15,000', impressions: '142,000', status: 'Active' },
              { brand: 'Pulse Energy Drink', campaign: 'Gamer Energy Break Campaign', budget: '$8,500', impressions: '89,500', status: 'Active' },
              { brand: 'Apex Gaming Hardware', campaign: 'Creator Sponsorship Program', budget: '$25,000', impressions: '310,000', status: 'Scheduled' },
            ].map((b, idx) => (
              <div key={idx} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{b.brand}</span>
                    <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 text-[10px] font-bold">Verified Brand</span>
                  </div>
                  <p className="text-slate-400 mt-1">{b.campaign} • Impressions Served: {b.impressions}</p>
                </div>
                <div className="text-right">
                  <span className="text-emerald-400 font-bold text-sm">{b.budget} Budget</span>
                  <p className="text-amber-400 text-[10px] font-bold">{b.status}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Global Servers */}
      {activeTab === 'servers' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white">Multi-Region Infrastructure Latency & Bandwidth</h3>
              <p className="text-xs text-slate-400">Global edge routing ensures viewers connect to the nearest node for ultra-low latency playback</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-semibold">
              Global CDN Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {[
              { region: '🌍 Africa Server', city: 'Johannesburg (Primary Edge)', ip: '102.165.18.42', latency: '12ms', load: '32%', status: 'Active' },
              { region: '🇪🇺 Europe Server', city: 'Frankfurt / London', ip: '185.220.101.5', latency: '38ms', load: '45%', status: 'Active' },
              { region: '🌎 North America Server', city: 'Virginia / Oregon', ip: '34.192.88.12', latency: '82ms', load: '58%', status: 'Active' },
              { region: '🌏 Asia Server', city: 'Singapore / Tokyo', ip: '128.199.20.91', latency: '108ms', load: '28%', status: 'Active' },
              { region: '🇦🇺 Australia Server', city: 'Sydney Edge Node', ip: '139.99.144.3', latency: '125ms', load: '19%', status: 'Active' },
            ].map((node, idx) => (
              <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">{node.region}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold">
                    {node.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px]">{node.city}</p>
                <div className="pt-2 border-t border-slate-800/80 flex justify-between text-[11px]">
                  <span className="text-slate-500 font-mono">{node.ip}</span>
                  <span className="text-emerald-400 font-mono font-bold">{node.latency}</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: node.load }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Users */}
      {activeTab === 'users' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-white">Registered Users Directory (142,500)</h3>
          <div className="space-y-2">
            {['alex_vibe', 'cyber_knight', 'maria_music', 'tech_guru'].map((u, i) => (
              <div key={i} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <span className="font-bold text-white">@{u}</span>
                <span className="text-slate-400">Joined Jul 2026 • Verified User</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Creators */}
      {activeTab === 'creators' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-white">Platform Creators ({creators.length})</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {creators.map((c) => (
              <div key={c.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-3 text-xs">
                <img src={c.avatar} className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <h4 className="font-bold text-white">{c.name}</h4>
                  <p className="text-slate-400">{c.followersCount.toLocaleString()} followers</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Live Streams */}
      {activeTab === 'streams' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-white">Live Broadcast Moderation</h3>
          <div className="space-y-3">
            {streams.map((s) => (
              <div key={s.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <div>
                  <h4 className="font-bold text-white">{s.title}</h4>
                  <p className="text-slate-400">{s.creator.name} • Category: {s.category}</p>
                </div>
                <button className="px-3 py-1 bg-red-950 text-red-300 rounded border border-red-800 font-semibold">
                  Feature Stream
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Reports & Moderation Queue */}
      {activeTab === 'reports' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Flag className="w-5 h-5 text-rose-500" />
                Moderation Queue & AI Assistance Engine
              </h3>
              <p className="text-slate-400">Human review flow paired with automated AI spam detection and scam flagging</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[11px] font-bold flex items-center gap-1.5">
                <Bot className="w-3.5 h-3.5" />
                AI Assistant Active
              </span>
            </div>
          </div>

          {/* AI Capabilities Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
              <span className="font-bold text-white block">Spam Auto-Filter</span>
              <span className="text-[10px] text-slate-400 block">Identifies repeated chat spam</span>
              <span className="text-emerald-400 font-extrabold text-[11px]">99.2% Accuracy</span>
            </div>
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
              <span className="font-bold text-white block">Scam Flagging</span>
              <span className="text-[10px] text-slate-400 block">Detects suspicious URLs & bots</span>
              <span className="text-emerald-400 font-extrabold text-[11px]">Active Shield</span>
            </div>
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
              <span className="font-bold text-white block">Abusive Text Triggers</span>
              <span className="text-[10px] text-slate-400 block">Auto-mutes toxic language</span>
              <span className="text-emerald-400 font-extrabold text-[11px]">Real-time Filter</span>
            </div>
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
              <span className="font-bold text-white block">Auto Category Classifier</span>
              <span className="text-[10px] text-slate-400 block">Suggests tags & categories</span>
              <span className="text-emerald-400 font-extrabold text-[11px]">Smart Ingest</span>
            </div>
          </div>

          {/* Reports Review Queue */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-white text-sm">Open Violation Tickets ({reportsQueue.length})</h4>
            {reportsQueue.length === 0 ? (
              <div className="p-8 text-center text-slate-400 bg-slate-950 rounded-2xl border border-slate-800">
                All moderation cases reviewed! Platform is clean.
              </div>
            ) : (
              reportsQueue.map((rep) => (
                <div key={rep.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-800/80 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-rose-400 text-sm">{rep.user}</span>
                      <span className="text-[10px] text-slate-500">Reported by {rep.reporter}</span>
                    </div>
                    <span className="px-2.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold uppercase">
                      Severity: {rep.severity}
                    </span>
                  </div>

                  <p className="text-slate-300 text-xs">
                    <strong className="text-white">Reason:</strong> {rep.reason}
                  </p>
                  <p className="text-slate-400 text-[11px]">
                    <strong className="text-slate-300">Stream Context:</strong> {rep.stream}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => {
                        setReportsQueue(reportsQueue.filter((r) => r.id !== rep.id));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                    >
                      No Action
                    </button>
                    <button
                      onClick={() => {
                        alert(`Warning sent to ${rep.user}`);
                        setReportsQueue(reportsQueue.filter((r) => r.id !== rep.id));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800 font-bold"
                    >
                      Issue Warning
                    </button>
                    <button
                      onClick={() => {
                        alert(`Content removed for case ${rep.id}`);
                        setReportsQueue(reportsQueue.filter((r) => r.id !== rep.id));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 font-bold"
                    >
                      Remove Content
                    </button>
                    <button
                      onClick={() => {
                        alert(`${rep.user} suspended for 7 days.`);
                        setReportsQueue(reportsQueue.filter((r) => r.id !== rep.id));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 font-bold"
                    >
                      Temp Suspend (7 Days)
                    </button>
                    <button
                      onClick={() => {
                        alert(`${rep.user} permanently banned.`);
                        setReportsQueue(reportsQueue.filter((r) => r.id !== rep.id));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold"
                    >
                      Permanent Suspension
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab: Categories */}
      {activeTab === 'categories' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-xs text-slate-300 space-y-2">
          <h3 className="text-sm font-bold text-white">Stream Categories Manager</h3>
          <p>Trending, Music, Gaming, Podcasts, Entertainment, News, Sports.</p>
        </div>
      )}

      {/* Tab: Revenue */}
      {activeTab === 'revenue' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-xs text-slate-300 space-y-2">
          <h3 className="text-sm font-bold text-white">Platform Financial Ledger</h3>
          <p>Total Revenue Jul 2026: $84,250. Creator Payouts: $58,970. Platform Net: $25,280.</p>
        </div>
      )}

      {/* Tab: HV100 Ads */}
      {activeTab === 'ads' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-white">HV100 Ad Network Manager</h3>
          <div className="space-y-3">
            {adCampaigns.map((ad) => (
              <div key={ad.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <div>
                  <h4 className="font-bold text-amber-400">{ad.title}</h4>
                  <p className="text-slate-400">{ad.advertiserName} • CPM ${ad.cpm.toFixed(2)}</p>
                </div>
                <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 font-bold">
                  Status: {ad.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Platform Settings Command Center */}
      {activeTab === 'settings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs text-slate-300">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-amber-400" />
                Enterprise Platform Settings
              </h3>
              <p className="text-slate-400">Configure global platform rules, user registration policies, monetization thresholds, and security parameters.</p>
            </div>
            <button
              onClick={() => alert('Platform Settings Saved Successfully!')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow-md transition-all flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" /> Save Configuration
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* User Registration & Access */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" /> User Registration Policy
              </h4>
              <p className="text-slate-400 text-[11px]">Control public signup availability across all platforms.</p>
              <div className="space-y-2">
                {(['Open', 'Invite-Only', 'Closed'] as const).map((mode) => (
                  <label key={mode} className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer ${userRegistrationMode === mode ? 'bg-amber-950/60 border-amber-500 text-white font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <span>{mode} Registration</span>
                    <input type="radio" name="reg_mode" checked={userRegistrationMode === mode} onChange={() => setUserRegistrationMode(mode)} className="accent-amber-500" />
                  </label>
                ))}
              </div>
            </div>

            {/* Creator Requirements & Levels */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-purple-400" /> Creator Verification Rules
              </h4>
              <p className="text-slate-400 text-[11px]">Identity verification and minimum follower thresholds for Go Live access.</p>
              <div className="space-y-2">
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span>ID Verification Required</span>
                  <input type="checkbox" defaultChecked className="accent-purple-500 w-4 h-4" />
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span>Level 1 Auto-Unlock</span>
                  <input type="checkbox" defaultChecked className="accent-purple-500 w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Community Guidelines & AI Moderation */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Flag className="w-4 h-4 text-rose-500" /> AI Auto-Moderation Level
              </h4>
              <p className="text-slate-400 text-[11px]">Filter chat spam, hate speech, and inappropriate content automatically.</p>
              <div className="space-y-2">
                {(['Strict', 'Balanced', 'Relaxed'] as const).map((lvl) => (
                  <label key={lvl} className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer ${aiModerationSensitivity === lvl ? 'bg-rose-950/60 border-rose-500 text-white font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <span>{lvl} AI Moderation</span>
                    <input type="radio" name="mod_mode" checked={aiModerationSensitivity === lvl} onChange={() => setAiModerationSensitivity(lvl)} className="accent-rose-500" />
                  </label>
                ))}
              </div>
            </div>

            {/* Monetization Rules & HV100 Payouts */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" /> Monetization & Payout Rules
              </h4>
              <p className="text-slate-400 text-[11px]">Minimum wallet withdrawal threshold for creator revenue.</p>
              <div className="space-y-2">
                {[25, 50, 100, 250].map((amt) => (
                  <label key={amt} className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer ${payoutThreshold === amt ? 'bg-emerald-950/60 border-emerald-500 text-white font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <span>Minimum Payout: ${amt}.00</span>
                    <input type="radio" name="payout_amt" checked={payoutThreshold === amt} onChange={() => setPayoutThreshold(amt)} className="accent-emerald-500" />
                  </label>
                ))}
              </div>
            </div>

            {/* Ad Frequency Policy */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" /> HV100 Ad Break Policies
              </h4>
              <p className="text-slate-400 text-[11px]">Maximum automated ad break density per live stream hour.</p>
              <div className="space-y-2">
                {['Minimal (1/hr)', 'Standard (2/hr)', 'Aggressive (4/hr)'].map((pol) => (
                  <label key={pol} className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer ${adFrequencyPolicy === pol ? 'bg-amber-950/60 border-amber-500 text-white font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    <span>{pol}</span>
                    <input type="radio" name="ad_pol" checked={adFrequencyPolicy === pol} onChange={() => setAdFrequencyPolicy(pol as any)} className="accent-amber-500" />
                  </label>
                ))}
              </div>
            </div>

            {/* Maintenance Mode & Supported Countries */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400" /> Maintenance Mode & Regions
              </h4>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">Maintenance Mode</span>
                  <span className="text-[10px] text-slate-400">Restricts public live streaming</span>
                </div>
                <button
                  onClick={() => setMaintenanceMode(!maintenanceMode)}
                  className={`px-3 py-1 rounded-xl font-bold ${maintenanceMode ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                >
                  {maintenanceMode ? 'ON' : 'OFF'}
                </button>
              </div>

              <div className="pt-2 space-y-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Supported Active Countries:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {['🇿🇦 SA', '🇳🇬 NG', '🇰🇪 KE', '🇬🇭 GH', '🇬🇧 UK', '🇺🇸 US'].map((c, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-slate-900 text-slate-200 border border-slate-800 font-bold text-[10px]">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Creator Levels & Unlocks */}
      {activeTab === 'creator_levels' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs text-slate-300">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-amber-400" />
                Gamified Creator Level Progression Matrix
              </h3>
              <p className="text-slate-400">Features unlock gradually as creators build reputation and audience engagement on HFArt.</p>
            </div>
            <span className="px-3 py-1 bg-amber-950 text-amber-300 border border-amber-800 font-extrabold rounded-full">
              Level System Active
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Level 1 */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 px-3 py-1 bg-slate-800 text-slate-300 text-[9px] font-extrabold rounded-bl-xl uppercase">Entry</div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-white font-extrabold flex items-center justify-center">L1</div>
                <div>
                  <h4 className="font-bold text-white text-sm">Level 1: Rookie</h4>
                  <span className="text-slate-400 text-[10px]">0 - 100 Followers</span>
                </div>
              </div>
              <ul className="space-y-2 pt-2 text-slate-300">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Go Live Access</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Creator Profile</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Follow System</li>
              </ul>
            </div>

            {/* Level 2 */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 px-3 py-1 bg-blue-950 text-blue-300 text-[9px] font-extrabold rounded-bl-xl uppercase">Rising</div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-900 text-blue-200 font-extrabold flex items-center justify-center">L2</div>
                <div>
                  <h4 className="font-bold text-white text-sm">Level 2: Rising</h4>
                  <span className="text-slate-400 text-[10px]">100 - 1,000 Followers</span>
                </div>
              </div>
              <ul className="space-y-2 pt-2 text-slate-300">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Stream Scheduling</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Channel Analytics</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> VOD Replays</li>
              </ul>
            </div>

            {/* Level 3 */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 px-3 py-1 bg-purple-950 text-purple-300 text-[9px] font-extrabold rounded-bl-xl uppercase">Pro</div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-900 text-purple-200 font-extrabold flex items-center justify-center">L3</div>
                <div>
                  <h4 className="font-bold text-white text-sm">Level 3: Pro Creator</h4>
                  <span className="text-slate-400 text-[10px]">1,000 - 10,000 Followers</span>
                </div>
              </div>
              <ul className="space-y-2 pt-2 text-slate-300">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Paid Subscriptions</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Ticketed Live Events</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Community Feed Posts</li>
              </ul>
            </div>

            {/* Level 4 */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-amber-500/50 space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 px-3 py-1 bg-amber-500 text-slate-950 text-[9px] font-extrabold rounded-bl-xl uppercase">Partner</div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-extrabold flex items-center justify-center">L4</div>
                <div>
                  <h4 className="font-bold text-amber-400 text-sm">Level 4: HFArt Partner</h4>
                  <span className="text-slate-400 text-[10px]">10,000+ Followers</span>
                </div>
              </div>
              <ul className="space-y-2 pt-2 text-slate-300">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> HV100 Ad Monetization</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Business Sponsorships</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Advanced AI Analytics</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Organization Accounts */}
      {activeTab === 'organizations' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 text-xs text-slate-300">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                Institutional Organization Accounts
              </h3>
              <p className="text-slate-400">Schools, Universities, Churches, Sports Clubs, Businesses, and Government Channels with verified badges.</p>
            </div>
            <button
              onClick={() => {
                const name = prompt('Organization Name:');
                if (name) {
                  setOrgAccounts([
                    ...orgAccounts,
                    { id: `org-${Date.now()}`, name, type: 'School', verified: true, admins: ['admin@org.com'], membersCount: 150 }
                  ]);
                }
              }}
              className="px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl"
            >
              + Register Organization
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {orgAccounts.map((org) => (
              <div key={org.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-white text-sm">{org.name}</h4>
                    {org.verified && (
                      <span className="px-2 py-0.5 rounded-full bg-blue-950 text-blue-400 border border-blue-800 font-extrabold text-[9px] uppercase">
                        ✓ Verified Org
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400 text-[10px]">Type: {org.type} • {org.membersCount} Channel Members</p>
                  <p className="text-slate-500 text-[10px]">Admins: {org.admins.join(', ')}</p>
                </div>
                <button
                  onClick={() => alert(`Managing permissions for ${org.name}`)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700"
                >
                  Manage Org
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: API */}
      {activeTab === 'api' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-xs text-slate-300 font-mono space-y-2">
          <h3 className="text-sm font-bold text-white font-sans">API Keys & Ingestion Webhooks</h3>
          <p>RTMP Ingest: rtmp://live.hfart.com/app</p>
          <p>Websocket Endpoint: wss://chat.hfart.com/v1</p>
        </div>
      )}

      {/* Tab: Logs */}
      {activeTab === 'logs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 font-mono text-xs text-slate-400 space-y-1">
          <p className="text-emerald-400">[2026-07-27 11:07:02] [HV100-ADS] Ad break triggered for stream str-1 (Duration: 15s)</p>
          <p className="text-blue-400">[2026-07-27 11:06:55] [CHAT] New chat connection established (User: You)</p>
          <p className="text-slate-500">[2026-07-27 11:05:30] [INGEST] Stream health check: 1080p60 OK</p>
        </div>
      )}

      {/* Tab: Development Roadmap & Future Ecosystem Vision */}
      {activeTab === 'roadmap' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Map className="w-5 h-5 text-rose-500" />
                HFArt Ecosystem Vision & Future Services Roadmap
              </h3>
              <p className="text-slate-400 text-xs">Scaling HFArt from a Creator Platform to a Global Digital Ecosystem.</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-rose-950 text-rose-300 border border-rose-800 font-bold text-xs">
              Global Ecosystem Strategy
            </span>
          </div>

          {/* Future Expansion Modules */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: '🎓 Educational Live Classes', desc: 'Interactive classrooms with live whiteboards, student Q&A, and course certification.', status: 'Beta Testing' },
              { title: '🎗️ Charity Fundraising Streams', desc: 'Real-time donation counters, transparent NGO payout ledgers, and match campaigns.', status: 'In Roadmap' },
              { title: '🎟️ Ticketed Virtual Events', desc: 'Pay-per-view live concerts, VIP backstages, and exclusive festival streaming passes.', status: 'In Development' },
              { title: '🤝 Creator Collaboration Tools', desc: 'Multi-creator co-streaming, joint chat lobbies, and automated split-revenue payouts.', status: 'Beta Testing' },
              { title: '🏫 Organization & School Accounts', desc: 'Institutional access tiers with dedicated domain SSO, compliance, and archived feeds.', status: 'Planning Phase' },
              { title: '🔌 Public APIs for Partners', desc: 'REST & GraphQL endpoints for third-party stream integrations, bot developers, and hardware OBS plugins.', status: 'Active Specs' },
            ].map((exp, i) => (
              <div key={i} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-white text-xs">{exp.title}</h4>
                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[9px] font-extrabold uppercase">
                    {exp.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">{exp.desc}</p>
              </div>
            ))}
          </div>

          <div className="space-y-3 pt-2 text-xs">
            <h4 className="font-bold text-white text-sm">Core Engineering Milestones</h4>
            {[
              { step: '1. Core Streaming Pipeline & Ingest', done: true },
              { step: '2. User Accounts, Firebase Authentication & Local Cache Security', done: true },
              { step: '3. Home Screen, Smart Search & Recommendation Engine', done: true },
              { step: '4. Creator Studio, Go Live & Multi-Device Control', done: true },
              { step: '5. Real-Time Chat Engine & Interactive Canvas', done: true },
              { step: '6. Creator Growth Engine & Team Roles Management', done: true },
              { step: '7. HV100 Automated Ad Breaks & Revenue Split Ledger (70/30)', done: true },
              { step: '8. Admin Control Operations Center (HOC) & Server Monitoring', done: true },
              { step: '9. Educational Live Classes & Ticketed Virtual Events', done: false },
              { step: '10. Public Open API SDK for Partners & Third-Party Plugins', done: false },
            ].map((r, i) => (
              <div key={i} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <span className={r.done ? 'text-white font-medium' : 'text-slate-500'}>{r.step}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${r.done ? 'bg-emerald-950 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                  {r.done ? 'Completed' : 'Planned'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
