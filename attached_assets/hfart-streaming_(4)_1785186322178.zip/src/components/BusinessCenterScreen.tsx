import React, { useState } from 'react';
import { 
  Building2, Sparkles, DollarSign, Play, Pause, Plus, CheckCircle2, AlertCircle, Search, Filter, Globe, Users, ArrowUpRight, BarChart3, Radio, FileText, Check, ShieldCheck, Video, Send, Eye, RefreshCw
} from 'lucide-react';
import { Creator, AdCampaign } from '../types';

interface BusinessCenterScreenProps {
  creators: Creator[];
  adCampaigns: AdCampaign[];
}

export const BusinessCenterScreen: React.FC<BusinessCenterScreenProps> = ({
  creators,
  adCampaigns: initialCampaigns,
}) => {
  const [activeTab, setActiveTab] = useState<'campaigns' | 'create_campaign' | 'sponsorships' | 'hv100_engine' | 'reports'>('campaigns');

  // Business Account State
  const [businessName, setBusinessName] = useState('Apex Sound & Media Global');
  const [isVerifiedBusiness] = useState(true);

  // Campaigns State
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(initialCampaigns);

  // Campaign Creation Form State
  const [newCampaignName, setNewCampaignName] = useState('');
  const [newCampaignGoal, setNewCampaignGoal] = useState('Brand Awareness & Live Ingest');
  const [selectedCountries, setSelectedCountries] = useState<string[]>(['South Africa', 'Kenya', 'Nigeria', 'United Kingdom']);
  const [selectedCategory, setSelectedCategory] = useState('Music');
  const [startDate, setStartDate] = useState('2026-08-01');
  const [endDate, setEndDate] = useState('2026-08-31');
  const [budgetUsd, setBudgetUsd] = useState(2500);
  const [videoAdUrl, setVideoAdUrl] = useState('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4');
  const [campaignSubmitted, setCampaignSubmitted] = useState(false);

  // Creator Search / Sponsorship Filters
  const [sponsorshipCategory, setSponsorshipCategory] = useState('All');
  const [sponsorshipCountry, setSponsorshipCountry] = useState('All');
  const [sponsorshipLanguage, setSponsorshipLanguage] = useState('All');
  const [minFollowers, setMinFollowers] = useState(0);
  const [proposalSentId, setProposalSentId] = useState<string | null>(null);

  // Filter Creators for Sponsorships
  const filteredCreators = creators.filter((c) => {
    if (sponsorshipCountry !== 'All' && c.country !== sponsorshipCountry) return false;
    if (c.followersCount < minFollowers) return false;
    return true;
  });

  const handleLaunchCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCampaignName.trim()) return;

    const newCampaign: AdCampaign = {
      id: `camp-${Date.now()}`,
      advertiserName: businessName,
      title: newCampaignName,
      videoUrl: videoAdUrl,
      durationSeconds: 15,
      cpm: 28.50,
      impressions: 0,
      status: 'Scheduled', // Enters Review state
      bannerImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    };

    setCampaigns([newCampaign, ...campaigns]);
    setCampaignSubmitted(true);
    setTimeout(() => {
      setCampaignSubmitted(false);
      setActiveTab('campaigns');
      setNewCampaignName('');
    }, 2500);
  };

  const handleToggleCampaignStatus = (campaignId: string) => {
    setCampaigns(campaigns.map(c => {
      if (c.id === campaignId) {
        const nextStatus = c.status === 'Active' ? 'Paused' : 'Active';
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  const handleSendSponsorship = (creatorId: string) => {
    setProposalSentId(creatorId);
    setTimeout(() => setProposalSentId(null), 3000);
  };

  return (
    <div id="business-center-view" className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6 text-xs text-slate-100">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" />
            <h1 className="text-lg font-bold text-white">{businessName}</h1>
            {isVerifiedBusiness && (
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-extrabold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Verified Business
              </span>
            )}
          </div>
          <p className="text-slate-400 text-xs">
            Manage video ad campaigns, creator sponsorships, and HV100 ad placements on HFArt.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('create_campaign')}
          className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 transition-transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Launch Ad Campaign</span>
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar border-b border-slate-800">
        {[
          { id: 'campaigns', label: 'Ad Campaigns', icon: Sparkles },
          { id: 'create_campaign', label: '+ Create Campaign', icon: Plus },
          { id: 'sponsorships', label: 'Creator Sponsorships', icon: Users },
          { id: 'hv100_engine', label: 'HV100 Ad Engine', icon: Radio },
          { id: 'reports', label: 'Campaign Reports', icon: BarChart3 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-slate-950 font-extrabold shadow-md shadow-amber-950/40'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab: Ad Campaigns List */}
      {activeTab === 'campaigns' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-white text-sm">Active & Scheduled Ad Campaigns</h3>
            <span className="text-slate-400">Total Budget Active: $14,500</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {campaigns.map((camp) => (
              <div key={camp.id} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <h4 className="font-bold text-white text-sm">{camp.title}</h4>
                    <p className="text-slate-400 text-[11px]">{camp.advertiserName} • CPM: ${camp.cpm.toFixed(2)}</p>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                    camp.status === 'Active' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    camp.status === 'Scheduled' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {camp.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Impressions</span>
                    <span className="font-bold text-white">{camp.impressions.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Duration</span>
                    <span className="font-bold text-white">{camp.durationSeconds}s</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Est. Reach</span>
                    <span className="font-bold text-emerald-400">45.2K</span>
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-between border-t border-slate-800">
                  <button
                    onClick={() => handleToggleCampaignStatus(camp.id)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center gap-1.5"
                  >
                    {camp.status === 'Active' ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{camp.status === 'Active' ? 'Pause Campaign' : 'Resume Campaign'}</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('reports')}
                    className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    View Report <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Campaign Creation Wizard */}
      {activeTab === 'create_campaign' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-5 h-5 text-amber-400" />
              Launch New HV100 Video Ad Campaign
            </h3>
            <p className="text-slate-400">Target live stream viewers across target countries, languages, and categories.</p>
          </div>

          {campaignSubmitted ? (
            <div className="p-8 text-center bg-slate-950 rounded-2xl border border-emerald-800/80 space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
              <h4 className="font-bold text-white text-base">Campaign Submitted For Review!</h4>
              <p className="text-slate-400 max-w-md mx-auto">
                Your advertisement is now queued for HV100 engine review. Once approved, it will automatically serve during scheduled live creator ad breaks.
              </p>
            </div>
          ) : (
            <form onSubmit={handleLaunchCampaign} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Campaign Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Summer Music Festival Tech Promo"
                    value={newCampaignName}
                    onChange={(e) => setNewCampaignName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Campaign Goal</label>
                  <select
                    value={newCampaignGoal}
                    onChange={(e) => setNewCampaignGoal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Brand Awareness & Live Ingest">Brand Awareness & Live Ingest</option>
                    <option value="Direct Conversions & Clickthrough">Direct Conversions & Clickthrough</option>
                    <option value="Event Ticket Sales">Event Ticket Sales</option>
                    <option value="App Downloads">App Downloads</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Target Category</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Music">Music</option>
                    <option value="Gaming">Gaming</option>
                    <option value="Sports">Sports</option>
                    <option value="Podcasts">Podcasts</option>
                    <option value="Entertainment">Entertainment</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Total Campaign Budget ($ USD)</label>
                  <input
                    type="number"
                    min="100"
                    step="50"
                    value={budgetUsd}
                    onChange={(e) => setBudgetUsd(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300 block">End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Video Ad Upload Selector */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <label className="font-bold text-slate-300 block">Video Advertisement Source URL</label>
                <input
                  type="text"
                  value={videoAdUrl}
                  onChange={(e) => setVideoAdUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                />
                <p className="text-[10px] text-slate-500">Supports MP4 / HLS streams up to 1080p60. Recommended ad duration: 15-30 seconds.</p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-extrabold shadow-lg shadow-amber-950/50 flex items-center gap-2 hover:scale-105 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Campaign for Review</span>
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Tab: Creator Sponsorships */}
      {activeTab === 'sponsorships' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                Creator Sponsorship Marketplace
              </h3>
              <p className="text-slate-400">Search and sponsor verified creators for sponsored live streams, brand shoutouts, and product placements.</p>
            </div>

            {/* Filter Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Country / Region</label>
                <select
                  value={sponsorshipCountry}
                  onChange={(e) => setSponsorshipCountry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                >
                  <option value="All">All Countries</option>
                  <option value="South Africa">South Africa</option>
                  <option value="Kenya">Kenya</option>
                  <option value="Nigeria">Nigeria</option>
                  <option value="United Kingdom">United Kingdom</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Minimum Followers</label>
                <select
                  value={minFollowers}
                  onChange={(e) => setMinFollowers(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                >
                  <option value={0}>Any Follower Count</option>
                  <option value={1000}>1,000+ Followers</option>
                  <option value={10000}>10,000+ Followers</option>
                  <option value={50000}>50,000+ Followers</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-bold block mb-1">Language</label>
                <select
                  value={sponsorshipLanguage}
                  onChange={(e) => setSponsorshipLanguage(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white"
                >
                  <option value="All">All Languages</option>
                  <option value="English">English</option>
                  <option value="IsiZulu">IsiZulu</option>
                  <option value="Swahili">Swahili</option>
                  <option value="French">French</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={() => {
                    setSponsorshipCountry('All');
                    setMinFollowers(0);
                    setSponsorshipLanguage('All');
                  }}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          </div>

          {/* Creators Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCreators.map((c) => (
              <div key={c.id} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-3">
                  <img src={c.avatar} alt={c.name} className="w-12 h-12 rounded-2xl object-cover ring-2 ring-amber-500/80" />
                  <div>
                    <h4 className="font-bold text-white text-sm">{c.name}</h4>
                    <p className="text-slate-400 text-[11px]">@{c.username} • {c.country || 'South Africa'}</p>
                  </div>
                </div>

                <p className="text-slate-300 text-[11px] line-clamp-2">{c.bio}</p>

                <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2 rounded-xl text-center text-[10px]">
                  <div>
                    <span className="text-slate-500 block">Followers</span>
                    <span className="font-bold text-white">{c.followersCount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Avg Viewers</span>
                    <span className="font-bold text-amber-400">1,240</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Engagement</span>
                    <span className="font-bold text-emerald-400">8.4%</span>
                  </div>
                </div>

                {proposalSentId === c.id ? (
                  <button disabled className="w-full py-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                    ✓ Sponsorship Proposal Sent!
                  </button>
                ) : (
                  <button
                    onClick={() => handleSendSponsorship(c.id)}
                    className="w-full py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold transition-all"
                  >
                    Send Sponsorship Offer
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: HV100 Ad Engine Logic & Revenue Split Diagram */}
      {activeTab === 'hv100_engine' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Radio className="w-5 h-5 text-amber-400" />
              HV100 Automated Ad Engine Architecture & Revenue Distribution
            </h3>
            <p className="text-slate-400">Real-time matching flow serving approved video ads during creator-scheduled live stream breaks with automated revenue sharing.</p>
          </div>

          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-6 gap-3 text-center">
              {[
                { step: '1. Ad Break Trigger', desc: 'Creator or timer initiates 15s/30s ad break', tag: 'Break Trigger' },
                { step: '2. Ad Played', desc: 'Engine matches geo, category & CPM bid', tag: 'Matching AI' },
                { step: '3. Completed Watch', desc: 'High completion rate (>94%) logged', tag: 'Ad Completion' },
                { step: '4. Revenue Generated', desc: '$28.50 average CPM calculated', tag: 'Gross Revenue' },
                { step: '5. Creator Share (70%)', desc: '$19.95 per 1,000 views to Creator Wallet', tag: 'Creator Payout' },
                { step: '6. Platform Share (30%)', desc: '$8.55 per 1,000 views to Platform Pool', tag: 'Platform Share' },
              ].map((s, idx) => (
                <div key={idx} className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-extrabold text-[9px] uppercase tracking-wider border border-amber-800">
                    {s.tag}
                  </span>
                  <h4 className="font-bold text-white text-xs">{s.step}</h4>
                  <p className="text-slate-400 text-[10px]">{s.desc}</p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-amber-400 font-bold text-xs block">HV100 Revenue Distribution Rule</span>
                <p className="text-slate-300 text-xs">Creators receive 70% direct payout on all ad breaks, while 30% supports Cloud Run CDN bandwidth, ingest servers, and security.</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-3 py-1.5 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-xs">Creator Share: 70%</span>
                <span className="px-3 py-1.5 rounded-xl bg-purple-950 text-purple-300 border border-purple-800 font-bold text-xs">Platform Share: 30%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Campaign Reports */}
      {activeTab === 'reports' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white">HV100 Business Analytics & Ad Reports</h3>
              <p className="text-slate-400">Detailed campaign metrics, viewer demographics, device breakdown, and remaining budget allocation.</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-xs">
              Live Real-Time Data
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Campaign Views</span>
              <span className="text-lg font-bold text-white">1,842,900</span>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Ad Plays</span>
              <span className="text-lg font-bold text-amber-400">1,720,400</span>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Completion Rate</span>
              <span className="text-lg font-bold text-emerald-400">94.2%</span>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Average CPM</span>
              <span className="text-lg font-bold text-purple-400">$28.50</span>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Spent Budget</span>
              <span className="text-lg font-bold text-rose-400">$12,400</span>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Budget Remaining</span>
              <span className="text-lg font-bold text-emerald-400">$3,600.00</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Target Countries */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm">Target Country Reach</h4>
              <div className="space-y-2">
                {[
                  { country: '🇿🇦 South Africa', share: '45%', impressions: '829,305' },
                  { country: '🇳🇬 Nigeria', share: '25%', impressions: '460,725' },
                  { country: '🇰🇪 Kenya', share: '18%', impressions: '331,722' },
                  { country: '🇬🇧 United Kingdom', share: '12%', impressions: '221,148' },
                ].map((item, i) => (
                  <div key={i} className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                    <span className="font-bold text-white">{item.country}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 text-[10px]">{item.impressions} plays</span>
                      <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-mono text-[10px] font-bold">{item.share}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Target Devices */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm">Device Distribution</h4>
              <div className="space-y-2">
                {[
                  { device: '📱 Mobile (iOS & Android)', share: '68%', count: '1,253,172' },
                  { device: '💻 Desktop Browsers', share: '24%', count: '442,296' },
                  { device: '📺 Smart TV & Casting', share: '8%', count: '147,432' },
                ].map((item, i) => (
                  <div key={i} className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                    <span className="font-bold text-white">{item.device}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 text-[10px]">{item.count}</span>
                      <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 font-mono text-[10px] font-bold">{item.share}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
