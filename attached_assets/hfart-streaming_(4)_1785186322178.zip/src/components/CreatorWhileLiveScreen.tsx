import React, { useState, useEffect } from 'react';
import { 
  Radio, Clock, Eye, Heart, MessageSquare, Share2, Sparkles, Power, Send, ShieldCheck,
  Wifi, Activity, Camera, Mic, MicOff, CameraOff, Sliders, Check, AlertTriangle, Video, Award, Film
} from 'lucide-react';
import { Stream, ChatMessage, AdBreakState } from '../types';
import { AdBreakModal } from './AdBreakModal';

interface CreatorWhileLiveScreenProps {
  stream: Stream;
  onEndStream: () => void;
}

export const CreatorWhileLiveScreen: React.FC<CreatorWhileLiveScreenProps> = ({
  stream,
  onEndStream,
}) => {
  const [durationSeconds, setDurationSeconds] = useState<number>(142); // starts at 02:22
  const [viewers, setViewers] = useState<number>(stream.viewerCount || 1240);
  const [peakViewers, setPeakViewers] = useState<number>(stream.viewerCount || 1580);
  const [likes, setLikes] = useState<number>(stream.likesCount || 3420);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', senderName: 'FanClub_Leader', senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80', message: 'Sound check is great! Ready for the session!', timestamp: '10:50 AM' },
    { id: '2', senderName: 'MusicGeek', senderAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80', message: 'Dropped 50 Sparkles! 💎', timestamp: '10:51 AM', isGift: true },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isAdBreakModalOpen, setIsAdBreakModalOpen] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);

  // Stream Hardware & Health Controls
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [networkHealth, setNetworkHealth] = useState<'excellent' | 'good' | 'fair' | 'poor'>('excellent');
  const [bitrateKbps, setBitrateKbps] = useState<number>(6500);
  const [fps, setFps] = useState<number>(60.0);
  const [streamQuality, setStreamQuality] = useState<'1080p60' | '720p60' | '480p' | '360p'>('1080p60');

  // Chat Mode Toggles
  const [slowMode, setSlowMode] = useState(false);
  const [followersOnly, setFollowersOnly] = useState(false);
  const [subscribersOnly, setSubscribersOnly] = useState(false);

  const [adBreak, setAdBreak] = useState<AdBreakState>({
    isScheduled: false,
    startsInSeconds: 0,
    breakDurationSeconds: 15,
    isBreakActive: false,
    currentAdIndex: 0,
  });

  // Stream Duration Timer & Network Quality Simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setDurationSeconds((prev) => prev + 1);
      if (Math.random() > 0.6) {
        setViewers((prev) => {
          const next = prev + Math.floor(Math.random() * 5);
          if (next > peakViewers) setPeakViewers(next);
          return next;
        });
      }

      // Simulate minor bitrate fluctuations & adaptive video quality management
      const fluc = Math.floor(Math.random() * 300) - 150;
      const newBitrate = Math.max(2000, Math.min(8000, bitrateKbps + fluc));
      setBitrateKbps(newBitrate);

      if (newBitrate < 3000) {
        setNetworkHealth('fair');
        setStreamQuality('720p60');
      } else if (newBitrate < 2200) {
        setNetworkHealth('poor');
        setStreamQuality('480p'); // Auto-reduce quality to keep stream running without dropping
      } else {
        setNetworkHealth('excellent');
        setStreamQuality('1080p60');
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [bitrateKbps, peakViewers]);

  // Ad Break countdown timer
  useEffect(() => {
    let interval: any = null;
    if (adBreak.isScheduled && adBreak.startsInSeconds > 0) {
      interval = setInterval(() => {
        setAdBreak((prev) => {
          if (prev.startsInSeconds <= 1) {
            return { ...prev, startsInSeconds: 0, isBreakActive: true };
          }
          return { ...prev, startsInSeconds: prev.startsInSeconds - 1 };
        });
      }, 1000);
    } else if (adBreak.isBreakActive && adBreak.breakDurationSeconds > 0) {
      interval = setInterval(() => {
        setAdBreak((prev) => {
          if (prev.breakDurationSeconds <= 1) {
            return { isScheduled: false, startsInSeconds: 0, breakDurationSeconds: 15, isBreakActive: false, currentAdIndex: 0 };
          }
          return { ...prev, breakDurationSeconds: prev.breakDurationSeconds - 1 };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [adBreak.isScheduled, adBreak.startsInSeconds, adBreak.isBreakActive, adBreak.breakDurationSeconds]);

  const formatDuration = (totalSec: number) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
    return hrs > 0 ? `${hrs}:${pad(mins)}:${pad(secs)}` : `${pad(mins)}:${pad(secs)}`;
  };

  const handleStartBreak = (startsInSeconds: number, durationSeconds: number) => {
    setAdBreak({
      isScheduled: true,
      startsInSeconds,
      breakDurationSeconds: durationSeconds,
      isBreakActive: false,
      currentAdIndex: 0,
    });
  };

  const handleInitiateEndStream = () => {
    setShowSummaryModal(true);
  };

  const handleConfirmEndStream = () => {
    setShowSummaryModal(false);
    onEndStream();
  };

  return (
    <div id="creator-while-live-container" className="px-4 sm:px-6 py-4 pb-20 space-y-6">
      
      {/* Broadcast Control Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        
        {/* Left Stats Row: LIVE badge, Duration, Viewers, Likes */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 text-white font-extrabold text-xs shadow-md uppercase tracking-wider">
            <Radio className="w-4 h-4 animate-pulse" />
            LIVE
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-200 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
            <Clock className="w-3.5 h-3.5 text-red-400" />
            <span>Duration: {formatDuration(durationSeconds)}</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-semibold text-white bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
            <Eye className="w-3.5 h-3.5 text-emerald-400" />
            <span>{viewers.toLocaleString()} Viewers</span>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-semibold text-white bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>{likes.toLocaleString()} Likes</span>
          </div>

          {/* Network Quality Indicator */}
          <div className="flex items-center gap-1.5 text-xs font-mono bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
            <Wifi className={`w-3.5 h-3.5 ${networkHealth === 'excellent' ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span className="text-slate-300">{bitrateKbps.toLocaleString()} kbps ({streamQuality})</span>
          </div>
        </div>

        {/* Right Action Controls: Break/Ads (HV100) & End Stream */}
        <div className="flex items-center gap-3">
          
          <button
            id="creator-ad-break-btn"
            onClick={() => setIsAdBreakModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-950/40 transition-transform active:scale-95 flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Break/Ads (HV100)</span>
          </button>

          <button
            id="creator-end-stream-btn"
            onClick={handleInitiateEndStream}
            className="px-4 py-2 rounded-xl bg-red-950 hover:bg-red-900 text-red-200 border border-red-800 font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <Power className="w-4 h-4 text-red-400" />
            <span>End Stream</span>
          </button>

        </div>

      </div>

      {/* Stream Health & Network Diagnostics Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 px-5 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-slate-400 font-medium">Health:</span>
            <span className="font-bold text-emerald-400 uppercase tracking-wider">
              {networkHealth} ({fps} FPS)
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <Video className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">Encoder:</span>
            <span className="text-white font-mono font-semibold">H.264 / AAC 48kHz</span>
          </div>

          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span className="text-slate-400">Adaptive Quality:</span>
            <span className="text-blue-300 font-semibold">{streamQuality} Active</span>
          </div>
        </div>

        {/* Media Hardware Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMicOn(!isMicOn)}
            className={`p-2 rounded-xl border transition-colors flex items-center gap-1 font-semibold ${
              isMicOn ? 'bg-slate-800 text-emerald-400 border-slate-700' : 'bg-red-950 text-red-400 border-red-800'
            }`}
            title="Toggle Microphone"
          >
            {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span>Mic {isMicOn ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={() => setIsCameraOn(!isCameraOn)}
            className={`p-2 rounded-xl border transition-colors flex items-center gap-1 font-semibold ${
              isCameraOn ? 'bg-slate-800 text-emerald-400 border-slate-700' : 'bg-red-950 text-red-400 border-red-800'
            }`}
            title="Toggle Camera"
          >
            {isCameraOn ? <Camera className="w-4 h-4" /> : <CameraOff className="w-4 h-4" />}
            <span>Cam {isCameraOn ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* Break Scheduled / Active Status Banner with Emergency Resume Button */}
      {adBreak.isScheduled && (
        <div className="bg-amber-950/90 border border-amber-500/60 rounded-2xl p-3 px-5 flex flex-wrap items-center justify-between gap-3 text-white animate-pulse">
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-amber-200">
              Break Scheduled: Ads begin in 00:0{adBreak.startsInSeconds} (Viewers notified)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAdBreak({ isScheduled: false, startsInSeconds: 0, breakDurationSeconds: 15, isBreakActive: false, currentAdIndex: 0 })}
              className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] shadow"
            >
              Cancel Break
            </button>
            <span className="text-[11px] bg-amber-900 px-2.5 py-1 rounded-full text-amber-300 font-semibold">
              HV100 CPM active
            </span>
          </div>
        </div>
      )}

      {adBreak.isBreakActive && (
        <div className="bg-emerald-950/90 border border-emerald-500/60 rounded-2xl p-3 px-5 flex flex-wrap items-center justify-between gap-3 text-white">
          <div className="flex items-center gap-3">
            <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
            <span className="text-xs font-bold text-emerald-200">
              Ad Break Active: Running HV100 sponsor ads ({adBreak.breakDurationSeconds}s remaining)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAdBreak({ isScheduled: false, startsInSeconds: 0, breakDurationSeconds: 15, isBreakActive: false, currentAdIndex: 0 })}
              className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] shadow-lg flex items-center gap-1.5 animate-bounce"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Emergency Resume Live</span>
            </button>
            <span className="text-[11px] bg-emerald-900 px-2.5 py-1 rounded-full text-emerald-300 font-semibold">
              Monetizing live
            </span>
          </div>
        </div>
      )}

      {/* Main Studio Broadcast Monitor & Comments */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Creator Camera Broadcast Box */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative aspect-video flex items-center justify-center">
          {isCameraOn ? (
            <img src={stream.thumbnail} alt="Broadcast feed" className="w-full h-full object-cover opacity-90" />
          ) : (
            <div className="w-full h-full bg-slate-950 flex flex-col items-center justify-center gap-3 text-slate-500">
              <CameraOff className="w-12 h-12 text-slate-600" />
              <p className="text-xs font-semibold">Camera output paused (Audio broadcasting)</p>
            </div>
          )}
          
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider flex items-center gap-1 shadow-md">
              <span className="w-2 h-2 rounded-full bg-white animate-ping"></span>
              YOUR BROADCAST IS LIVE
            </span>
          </div>

          <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur-md p-3 rounded-2xl border border-white/10 flex items-center justify-between text-xs text-white">
            <span className="font-semibold">{stream.title}</span>
            <span className="text-amber-400 font-medium">Recording: Active ({streamQuality})</span>
          </div>
        </div>

        {/* Live Comments & Chat Moderation Sidebar */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl flex flex-col h-[520px] shadow-xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex flex-col gap-2 bg-slate-950/40">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-red-500" />
                <h3 className="text-xs font-bold text-white">Live Chat Moderation</h3>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Streamer Control</span>
            </div>

            {/* Chat Mode Toggles */}
            <div className="flex items-center gap-2 text-[10px] pt-1">
              <button
                onClick={() => setSlowMode(!slowMode)}
                className={`px-2 py-1 rounded-md font-semibold transition-colors ${
                  slowMode ? 'bg-amber-500 text-black font-bold' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Slow Mode {slowMode ? '(5s)' : 'Off'}
              </button>
              <button
                onClick={() => setFollowersOnly(!followersOnly)}
                className={`px-2 py-1 rounded-md font-semibold transition-colors ${
                  followersOnly ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Followers Only
              </button>
              <button
                onClick={() => setSubscribersOnly(!subscribersOnly)}
                className={`px-2 py-1 rounded-md font-semibold transition-colors ${
                  subscribersOnly ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Subscribers Only
              </button>
            </div>
          </div>

          <div className="flex-1 p-4 overflow-y-auto space-y-3 no-scrollbar">
            {chatMessages.map((msg, idx) => (
              <div key={msg.id ? `${msg.id}-${idx}` : `chat-${idx}`} className="flex items-start gap-2 text-xs">
                <img src={msg.senderAvatar} className="w-5 h-5 rounded-full" />
                <div>
                  <span className="font-bold text-slate-300">{msg.senderName}: </span>
                  <span className="text-slate-200">{msg.message}</span>
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!inputMessage.trim()) return;
              setChatMessages((prev) => [
                ...prev,
                {
                  id: Date.now().toString(),
                  senderName: `${stream.creator.name} (Broadcaster)`,
                  senderAvatar: stream.creator.avatar,
                  message: inputMessage,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  isBadge: 'STREAMER'
                }
              ]);
              setInputMessage('');
            }}
            className="p-3 border-t border-slate-800 bg-slate-950/60 flex gap-2"
          >
            <input
              type="text"
              placeholder="Reply to chat..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
            />
            <button type="submit" className="px-3 py-2 bg-red-600 hover:bg-red-500 rounded-xl text-xs text-white font-bold">
              Send
            </button>
          </form>
        </div>

      </div>

      {/* Stream End Summary Modal */}
      {showSummaryModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 text-center">
            
            <div className="w-16 h-16 rounded-full bg-red-950 border border-red-800 text-red-500 flex items-center justify-center mx-auto shadow-xl">
              <Radio className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-extrabold text-white">Stream Ending Confirmation</h2>
              <p className="text-xs text-slate-400">
                Are you sure you want to end your live stream? Replay analytics will be saved to your dashboard.
              </p>
            </div>

            {/* Live Session Summary Breakdown */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-left space-y-3 text-xs">
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Total Duration</span>
                <span className="font-mono text-white font-bold">{formatDuration(durationSeconds)}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Peak Concurrent Viewers</span>
                <span className="font-bold text-emerald-400">{peakViewers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Total Likes Received</span>
                <span className="font-bold text-rose-400">{likes.toLocaleString()}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Recording Status</span>
                <span className="font-bold text-blue-400 flex items-center gap-1">
                  <Film className="w-3.5 h-3.5" /> Replay Saved (1080p)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSummaryModal(false)}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
              >
                Keep Live
              </button>
              <button
                onClick={handleConfirmEndStream}
                className="flex-1 py-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-lg shadow-red-950/50 transition-colors"
              >
                End Stream Now
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Schedule Break Modal */}
      <AdBreakModal
        isOpen={isAdBreakModalOpen}
        onClose={() => setIsAdBreakModalOpen(false)}
        onStartBreak={handleStartBreak}
      />

    </div>
  );
};
