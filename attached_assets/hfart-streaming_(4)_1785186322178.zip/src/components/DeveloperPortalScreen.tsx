import React, { useState } from 'react';
import { 
  Key, Code2, Terminal, Copy, Check, RefreshCw, Layers, ShieldCheck, Database, Globe, Cpu, Server
} from 'lucide-react';

export const DeveloperPortalScreen: React.FC = () => {
  const [apiKey, setApiKey] = useState('hf_live_pk_98127394812039128391');
  const [showKey, setShowKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('https://api.mybrand.com/webhooks/hfart-stream-events');
  const [webhookSaved, setWebhookSaved] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleRegenerateKey = () => {
    setApiKey(`hf_live_pk_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`);
    alert('API Key regenerated successfully!');
  };

  return (
    <div id="developer-portal-view" className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6 text-xs text-slate-100">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-2">
        <div className="flex items-center gap-2">
          <Key className="w-5 h-5 text-rose-500" />
          <h1 className="text-lg font-bold text-white">HFArt Developer Portal</h1>
        </div>
        <p className="text-slate-400 text-xs">
          Build custom RTMP streaming integrations, webhook event listeners, and API endpoints for HFArt.
        </p>
      </div>

      {/* API Key Management */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" />
            API Keys & Authentication Tokens
          </h3>
          <button
            onClick={handleRegenerateKey}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Regenerate Secret Key
          </button>
        </div>

        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
          <span className="text-slate-400 font-bold block text-[11px]">Production Live API Secret Key</span>
          <div className="flex items-center justify-between font-mono">
            <span>{showKey ? apiKey : '••••••••••••••••••••••••••••••••••••••••'}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowKey(!showKey)}
                className="text-slate-400 hover:text-white"
              >
                {showKey ? 'Hide' : 'Reveal'}
              </button>
              <button
                onClick={() => handleCopy(apiKey)}
                className="text-rose-400 hover:text-rose-300 flex items-center gap-1 font-sans font-bold"
              >
                {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey ? 'Copied' : 'Copy Key'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Webhooks Config */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-white text-sm flex items-center gap-2">
          <Terminal className="w-4 h-4 text-rose-500" />
          Stream Event Webhooks Listener
        </h3>
        <div className="space-y-2">
          <label className="text-slate-300 font-bold block">Webhook Event Destination Endpoint</label>
          <div className="flex gap-2">
            <input
              type="url"
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono focus:outline-none focus:border-rose-500"
            />
            <button
              onClick={() => {
                setWebhookSaved(true);
                setTimeout(() => setWebhookSaved(false), 2000);
              }}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold"
            >
              {webhookSaved ? 'Saved!' : 'Save Endpoint'}
            </button>
          </div>
        </div>
      </div>

      {/* Code Sample */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center gap-2">
          <Code2 className="w-4 h-4 text-emerald-400" />
          TypeScript SDK Quickstart Example
        </h3>
        <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-emerald-400 overflow-x-auto text-[11px] leading-relaxed">
{`import { HFArtClient } from '@hfart/sdk';

const hfart = new HFArtClient({
  apiKey: process.env.HFART_API_KEY,
  region: 'africa-south'
});

// Subscribe to real-time live stream ingest events
const stream = await hfart.streams.getLiveStream('str-101');
console.log('Active viewers:', stream.viewerCount);`}
        </pre>
      </div>

    </div>
  );
};
