import React, { useState } from 'react';
import { 
  Video, Camera, Image, Eye, MessageSquare, Film, Share2, Radio, Check, Sparkles, Sliders
} from 'lucide-react';
import { CategoryType, Stream, Creator } from '../types';

interface GoLiveSetupScreenProps {
  currentCreator: Creator;
  onStartLiveStream: (streamData: Partial<Stream>) => void;
}

export const GoLiveSetupScreen: React.FC<GoLiveSetupScreenProps> = ({
  currentCreator,
  onStartLiveStream,
}) => {
  const [title, setTitle] = useState('🔥 Friday Night Synth Session & Viewer Requests!');
  const [description, setDescription] = useState('Streaming live electronic music, improvising on hardware synths and answering viewer Q&A.');
  const [category, setCategory] = useState<CategoryType>('Music');
  const [thumbnail, setThumbnail] = useState('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80');
  const [visibility, setVisibility] = useState<'Public' | 'Followers' | 'Subscribers'>('Public');
  const [allowClips, setAllowClips] = useState(true);
  const [enableChat, setEnableChat] = useState(true);
  const [recordStream, setRecordStream] = useState(true);
  const [facebookShare, setFacebookShare] = useState(false);

  const sampleThumbnails = [
    'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStartLiveStream({
      title,
      description,
      category,
      thumbnail,
      visibility,
      allowClips,
      enableChat,
      recordStream,
      isLive: true,
      viewerCount: 1,
      likesCount: 0,
      tags: ['Live', category, 'HFArtStream'],
      creator: { ...currentCreator, isLive: true }
    });
  };

  return (
    <div id="go-live-setup-container" className="px-4 sm:px-6 py-6 pb-24 max-w-4xl mx-auto space-y-6">
      
      {/* Page Title */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-950/50">
          <Radio className="w-5 h-5 animate-pulse" />
        </div>
        <div>
          <h1 className="text-lg sm:text-xl font-bold text-white">Go Live - Stream Setup</h1>
          <p className="text-xs text-slate-400">Configure your broadcast settings before going live to your audience</p>
        </div>
      </div>

      {/* Main Setup Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl">
        
        {/* Stream Camera Preview Box */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
            <Camera className="w-4 h-4 text-red-500" />
            Camera & Stream Feed Preview
          </label>
          <div className="relative aspect-video bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center">
            <img src={thumbnail} alt="Thumbnail preview" className="w-full h-full object-cover opacity-80" />
            <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center gap-2 text-center p-4">
              <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg animate-pulse">
                <Video className="w-6 h-6" />
              </div>
              <span className="text-xs font-semibold text-white">Camera Feed Ready (HD 1080p)</span>
              <span className="text-[10px] text-slate-400">Audio Input: Built-in Stereo Mic (Active)</span>
            </div>
          </div>
        </div>

        {/* Stream Title */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Stream Title</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter an catchy title for your live stream..."
            className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
          />
        </div>

        {/* Description */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Description</label>
          <textarea
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Tell viewers what this stream is about..."
            className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
          />
        </div>

        {/* Category & Visibility Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Category */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as CategoryType)}
              className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-red-500"
            >
              {['Music', 'Gaming', 'Podcasts', 'Entertainment', 'News', 'Sports'].map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Visibility: Public / Followers / Subscribers */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Visibility</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Public', 'Followers', 'Subscribers'] as const).map((vis) => (
                <button
                  type="button"
                  key={vis}
                  onClick={() => setVisibility(vis)}
                  className={`py-2 px-2 rounded-xl text-[11px] font-semibold border transition-all ${
                    visibility === vis
                      ? 'bg-red-600 text-white border-red-500 shadow-md'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {vis}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Select Thumbnail */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Image className="w-4 h-4 text-amber-400" />
              Stream Thumbnail
            </span>
            <span className="text-[10px] text-slate-400">Click a preset or enter URL</span>
          </label>

          <div className="grid grid-cols-4 gap-3">
            {sampleThumbnails.map((url, idx) => (
              <div
                key={idx}
                onClick={() => setThumbnail(url)}
                className={`aspect-video rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                  thumbnail === url ? 'border-red-500 ring-2 ring-red-500/50 scale-105' : 'border-slate-800 opacity-60 hover:opacity-100'
                }`}
              >
                <img src={url} alt="Preset" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Feature Toggles */}
        <div className="space-y-3 border-t border-slate-800 pt-5">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            Interactive Stream Controls
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Allow Clips */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div className="text-xs">
                <span className="font-semibold text-white block">Allow Clips</span>
                <span className="text-[10px] text-slate-400">Viewers can create 30s clips</span>
              </div>
              <input
                type="checkbox"
                checked={allowClips}
                onChange={(e) => setAllowClips(e.target.checked)}
                className="w-4 h-4 accent-red-600 rounded"
              />
            </div>

            {/* Enable Chat */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div className="text-xs">
                <span className="font-semibold text-white block">Enable Chat</span>
                <span className="text-[10px] text-slate-400">Allow live chat messages</span>
              </div>
              <input
                type="checkbox"
                checked={enableChat}
                onChange={(e) => setEnableChat(e.target.checked)}
                className="w-4 h-4 accent-red-600 rounded"
              />
            </div>

            {/* Record Stream */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div className="text-xs">
                <span className="font-semibold text-white block">Record Stream</span>
                <span className="text-[10px] text-slate-400">Save recording to profile VODs</span>
              </div>
              <input
                type="checkbox"
                checked={recordStream}
                onChange={(e) => setRecordStream(e.target.checked)}
                className="w-4 h-4 accent-red-600 rounded"
              />
            </div>

            {/* Facebook Share (Future) */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-2xl border border-slate-800">
              <div className="text-xs">
                <span className="font-semibold text-white block flex items-center gap-1">
                  Facebook Share
                  <span className="text-[9px] px-1 bg-blue-950 text-blue-400 rounded">Future</span>
                </span>
                <span className="text-[10px] text-slate-400">Crosspost live to Facebook page</span>
              </div>
              <input
                type="checkbox"
                checked={facebookShare}
                onChange={(e) => setFacebookShare(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded"
              />
            </div>

          </div>
        </div>

        {/* Go Live Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold text-sm shadow-xl shadow-red-950/60 transition-all flex items-center justify-center gap-2 hover:scale-[1.01]"
          >
            <Radio className="w-5 h-5 animate-pulse" />
            <span>Go Live Now</span>
          </button>
        </div>

      </form>
    </div>
  );
};
