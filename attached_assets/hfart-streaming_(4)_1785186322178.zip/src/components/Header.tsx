import React from 'react';
import { Search, Radio, Shield, Video, User, Bell, Sparkles, LogIn, Building2, Code2 } from 'lucide-react';
import { ViewMode, Creator, UserProfile } from '../types';

interface HeaderProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  currentCreator: Creator;
  currentUser?: UserProfile | null;
  onOpenCreateModal: () => void;
  onOpenNotificationsModal: () => void;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  viewMode,
  setViewMode,
  searchQuery,
  setSearchQuery,
  currentCreator,
  currentUser,
  onOpenCreateModal,
  onOpenNotificationsModal,
  onOpenAuthModal,
}) => {
  return (
    <header id="main-header" className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div id="header-container" className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        
        {/* Logo & Brand */}
        <div id="brand-area" className="flex items-center gap-3 cursor-pointer" onClick={() => setViewMode('home')}>
          <div id="brand-icon" className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 flex items-center justify-center shadow-lg shadow-red-950/40">
            <Radio className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span id="brand-title" className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-rose-200 bg-clip-text text-transparent">
                HFArt
              </span>
              <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-red-600/90 text-white uppercase tracking-wider">
                Live
              </span>
            </div>
            <p className="text-[10px] text-slate-400 -mt-0.5 hidden sm:block">Connecting Creators With The World</p>
          </div>
        </div>

        {/* Global Search Bar */}
        <div id="header-search" className="flex-1 max-w-md hidden md:block">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search streams, creators, podcasts, gaming..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800/90 border border-slate-700/80 rounded-full pl-10 pr-4 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-all"
            />
          </div>
        </div>

        {/* Action Controls */}
        <div id="header-actions" className="flex items-center gap-2 sm:gap-3">
          
          {/* Go Live CTA */}
          <button
            id="header-go-live-btn"
            onClick={() => setViewMode('go_live_setup')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-md shadow-red-900/30 transition-all hover:scale-105 active:scale-95"
          >
            <Video className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Go Live</span>
          </button>

          {/* Creator Studio shortcut */}
          <button
            id="header-creator-studio-btn"
            onClick={() => setViewMode('creator_studio')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
              viewMode === 'creator_studio'
                ? 'bg-slate-800 text-white border-slate-600'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Studio</span>
          </button>

          {/* Business Center button */}
          <button
            id="header-business-btn"
            onClick={() => setViewMode('business_center')}
            className={`p-2 rounded-full border transition-all ${
              viewMode === 'business_center'
                ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:bg-slate-800 hover:text-amber-300'
            }`}
            title="Business Center & HV100 Ads"
          >
            <Building2 className="w-4 h-4" />
          </button>

          {/* Developer Portal button */}
          <button
            id="header-developer-btn"
            onClick={() => setViewMode('developer_portal')}
            className={`p-2 rounded-full border transition-all ${
              viewMode === 'developer_portal'
                ? 'bg-purple-950/60 text-purple-300 border-purple-800'
                : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:bg-slate-800 hover:text-purple-300'
            }`}
            title="Developer Portal"
          >
            <Code2 className="w-4 h-4" />
          </button>

          {/* Admin Dashboard button */}
          <button
            id="header-admin-btn"
            onClick={() => setViewMode('admin_dashboard')}
            className={`p-2 rounded-full border transition-all ${
              viewMode === 'admin_dashboard'
                ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:bg-slate-800 hover:text-slate-200'
            }`}
            title="Admin Operations Center"
          >
            <Shield className="w-4 h-4" />
          </button>

          {/* Notifications button */}
          <button
            id="header-notif-btn"
            onClick={onOpenNotificationsModal}
            className="p-2 rounded-full bg-slate-800/60 text-slate-300 border border-slate-700/50 hover:bg-slate-800 hover:text-white relative"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="w-2 h-2 rounded-full bg-red-500 absolute top-1.5 right-1.5 ring-2 ring-slate-900 animate-ping"></span>
          </button>

          {/* Profile / Auth Button */}
          {currentUser ? (
            <button
              id="header-profile-btn"
              onClick={() => setViewMode('profile')}
              className="flex items-center gap-2 p-1 rounded-full hover:bg-slate-800 transition-all border border-transparent hover:border-slate-700"
              title={currentUser.fullName}
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.fullName}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-red-500/80"
              />
            </button>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="px-3.5 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white flex items-center gap-1.5 transition-all"
            >
              <LogIn className="w-3.5 h-3.5 text-rose-400" />
              <span>Log In</span>
            </button>
          )}

        </div>

      </div>
    </header>
  );
};
