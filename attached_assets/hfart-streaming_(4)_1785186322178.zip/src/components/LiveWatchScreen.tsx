import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, Send, Share2, Eye, UserPlus, Check, Sparkles, Volume2, VolumeX, 
  Maximize, Shield, Clock, Play, DollarSign, MessageSquare, AlertCircle, Award, Gift,
  Smile, Trash2, Ban, MicOff, Settings, CheckCircle2, Copy
} from 'lucide-react';
import { Stream, ChatMessage, AdBreakState, VirtualGift } from '../types';
import { AdBreakModal } from './AdBreakModal';
import { subscribeToStreamChat, sendFirestoreChatMessage, likeFirestoreStream } from '../lib/firestoreService';

interface LiveWatchScreenProps {
  stream: Stream;
  onToggleFollow: (creatorId: string) => void;
  onToggleSubscribe: (creatorId: string) => void;
  onSelectCreator: (creatorId: string) => void;
}

const AVAILABLE_GIFTS: VirtualGift[] = [
  { id: 'g1', name: 'Super Sparkle', icon: '💎', costSparkles: 100, color: 'from-blue-500 to-cyan-400' },
  { id: 'g2', name: 'Safari Gold Lion', icon: '🦁', costSparkles: 500, color: 'from-amber-500 to-yellow-400' },
  { id: 'g3', name: 'Platinum Crown', icon: '👑', costSparkles: 1000, color: 'from-purple-500 to-rose-400' },
  { id: 'g4', name: 'South Africa Flag', icon: '🇿🇦', costSparkles: 250, color: 'from-emerald-500 to-amber-400' },
];

export const LiveWatchScreen: React.FC<LiveWatchScreenProps> = ({
  stream,
  onToggleFollow,
  onToggleSubscribe,
  onSelectCreator,
}) => {
  const [likes, setLikes] = useState<number>(stream.likesCount);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(stream.enableChat ? [
    { id: '1', senderName: 'VibeLover', senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80', message: 'The stream quality today is top notch! 🔥', timestamp: '10:45 AM' },
    { id: '2', senderName: 'CyberFan', senderAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80', message: 'Hello from HFArt Live stream in South Africa! 🇿🇦', timestamp: '10:46 AM', isBadge: 'SUB 6 MO' },
  ] : []);
  const [inputMessage, setInputMessage] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; left: number; emoji: string }[]>([]);
  
  // Moderation states
  const [isSlowMode, setIsSlowMode] = useState(false);
  const [isFollowersOnly, setIsFollowersOnly] = useState(false);
  const [isSubscribersOnly, setIsSubscribersOnly] = useState(false);
  const [showModPanel, setShowModPanel] = useState(false);
  const [mutedUsers, setMutedUsers] = useState<string[]>([]);

  // Gifts & Donations & Reactions
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [isDonateModalOpen, setIsDonateModalOpen] = useState(false);
  const [donateAmount, setDonateAmount] = useState(10);
  const [donateMessage, setDonateMessage] = useState('');
  const [userSparkles, setUserSparkles] = useState(2500);
  const [showAiCaptions, setShowAiCaptions] = useState(false);
  const [pinnedMessage, setPinnedMessage] = useState<string>('📌 Creator: Welcome everyone to HFArt Live stream! Subscribe for VIP emotes!');

  // Ad Break state management
  const [adBreak, setAdBreak] = useState<AdBreakState>({
    isScheduled: false,
    startsInSeconds: 0,
    breakDurationSeconds: 15,
    isBreakActive: false,
    currentAdIndex: 0,
  });
  const [isAdBreakModalOpen, setIsAdBreakModalOpen] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Subscribe to real-time chat from Firestore
  useEffect(() => {
    if (!stream?.id) return;
    const unsubscribe = subscribeToStreamChat(stream.id, (msgs) => {
      setChatMessages(msgs);
    });
    return () => unsubscribe();
  }, [stream?.id]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // Timer loop for Ad Break countdown and Ad execution
  useEffect(() => {
    let interval: any = null;

    if (adBreak.isScheduled && adBreak.startsInSeconds > 0) {
      interval = setInterval(() => {
        setAdBreak((prev) => {
          if (prev.startsInSeconds <= 1) {
            return {
              ...prev,
              startsInSeconds: 0,
              isBreakActive: true,
            };
          }
          return { ...prev, startsInSeconds: prev.startsInSeconds - 1 };
        });
      }, 1000);
    } else if (adBreak.isBreakActive && adBreak.breakDurationSeconds > 0) {
      interval = setInterval(() => {
        setAdBreak((prev) => {
          if (prev.breakDurationSeconds <= 1) {
            return {
              isScheduled: false,
              startsInSeconds: 0,
              breakDurationSeconds: 15,
              isBreakActive: false,
              currentAdIndex: 0,
            };
          }
          return { ...prev, breakDurationSeconds: prev.breakDurationSeconds - 1 };
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [adBreak.isScheduled, adBreak.startsInSeconds, adBreak.isBreakActive, adBreak.breakDurationSeconds]);

  // Handle viewer liking or reacting with custom emoji
  const handleReaction = (emoji: string = '❤️') => {
    setLikes((prev) => prev + 1);
    likeFirestoreStream(stream.id);
    const newHeart = { id: Date.now(), left: Math.random() * 60 + 20, emoji };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 1500);
  };

  // Handle sending chat message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const msgContent = inputMessage.trim();
    setInputMessage('');

    sendFirestoreChatMessage(stream.id, {
      senderName: 'You',
      senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      message: msgContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isBadge: 'VIP'
    });
  };

  // Moderator actions
  const handleDeleteMessage = (msgId: string) => {
    setChatMessages((prev) => prev.filter((m) => m.id !== msgId));
  };

  const handleMuteUser = (senderName: string) => {
    setMutedUsers((prev) => [...prev, senderName]);
    setChatMessages((prev) => prev.filter((m) => m.senderName !== senderName));
  };

  const handleSendGift = (gift: VirtualGift) => {
    if (userSparkles < gift.costSparkles) {
      alert('Not enough HFArt Sparkles balance!');
      return;
    }
    setUserSparkles((prev) => prev - gift.costSparkles);
    const giftMsg: ChatMessage = {
      id: Date.now().toString(),
      senderName: 'You',
      senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      message: `Sent ${gift.name} ${gift.icon}! (${gift.costSparkles} Sparkles)`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isBadge: 'VIP',
      isGift: true,
      giftType: gift.name,
    };
    setChatMessages((prev) => [...prev, giftMsg]);
    setIsGiftModalOpen(false);
    handleReaction(gift.icon);
  };

  const handleConfirmDonation = () => {
    if (donateAmount <= 0) return;
    const donateMsg: ChatMessage = {
      id: Date.now().toString(),
      senderName: 'You',
      senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      message: `💰 Donated $${donateAmount}.00 USD: "${donateMessage || 'Keep up the awesome streams!'}"`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isBadge: 'SUPPORTER',
      isGift: true,
    };
    sendFirestoreChatMessage(stream.id, donateMsg);
    setChatMessages((prev) => [...prev, donateMsg]);
    setIsDonateModalOpen(false);
    setDonateMessage('');
    handleReaction('💰');
  };

  // Trigger simulated Ad Break
  const handleStartBreak = (startsInSeconds: number, durationSeconds: number) => {
    setAdBreak({
      isScheduled: true,
      startsInSeconds,
      breakDurationSeconds: durationSeconds,
      isBreakActive: false,
      currentAdIndex: 0,
    });
  };

  const creator = stream.creator;

  return (
    <div id="live-watch-container" className="px-4 sm:px-6 py-4 pb-20 space-y-6">
      
      {/* Top Banner if Ad Break is scheduled */}
      {adBreak.isScheduled && (
        <div id="viewer-break-countdown-banner" className="bg-amber-950/90 border border-amber-500/60 rounded-2xl p-3 px-5 flex items-center justify-between text-white animate-pulse shadow-lg">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-ping"></span>
            <div>
              <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider">Creator Break Scheduled</h4>
              <p className="text-xs text-amber-100/90 font-mono">
                Ads begin in 00:0{adBreak.startsInSeconds}
              </p>
            </div>
          </div>
          <span className="text-[11px] bg-amber-900/80 px-2.5 py-1 rounded-full text-amber-300 font-semibold border border-amber-600/50">
            HV100 Ad Break
          </span>
        </div>
      )}

      {/* Main Stream Player & Chat Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Video Player & Stream Details */}
        <div className="lg:col-span-2 space-y-4">
          
          {/* Stream Canvas / Player Box */}
          <div className="relative aspect-video bg-black rounded-3xl overflow-hidden border border-slate-800 shadow-2xl group">
            
            {/* If Ad Break is active, display the HV100 Ad Video Canvas */}
            {adBreak.isBreakActive ? (
              <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-6 text-center space-y-4 animate-in fade-in">
                <div className="w-full max-w-md aspect-video rounded-2xl overflow-hidden relative shadow-2xl border border-amber-500/50">
                  <img
                    src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80"
                    alt="HV100 Sponsored Ad"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold text-[11px]">
                    HV100 SPONSORED AD
                  </div>
                  <div className="absolute bottom-3 left-3 right-3 text-left">
                    <h4 className="text-sm font-extrabold text-white">HV100 Ultra Low Latency Audio Gear</h4>
                    <p className="text-[11px] text-slate-300">Experience lossless studio sound anywhere.</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-xs text-amber-400 font-bold uppercase tracking-wider flex items-center justify-center gap-2">
                    <Clock className="w-4 h-4 animate-spin text-amber-400" />
                    Creator Break in Progress
                  </p>
                  <p className="text-sm font-mono text-white font-semibold">
                    Resuming live stream in 00:{adBreak.breakDurationSeconds < 10 ? `0${adBreak.breakDurationSeconds}` : adBreak.breakDurationSeconds}
                  </p>
                </div>
              </div>
            ) : (
              /* Live Stream Video Feed Canvas */
              <div className="w-full h-full relative">
                <img
                  src={stream.thumbnail}
                  alt={stream.title}
                  className="w-full h-full object-cover"
                />

                {/* Animated Floating Reactions */}
                {floatingHearts.map((h) => (
                  <div
                    key={h.id}
                    className="absolute bottom-12 text-2xl animate-bounce pointer-events-none transition-all duration-1000"
                    style={{ left: `${h.left}%`, opacity: 0.9 }}
                  >
                    {h.emoji}
                  </div>
                ))}

                {/* Top Overlay Controls */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-red-600 text-white font-bold text-xs shadow-lg uppercase tracking-wide">
                      <span className="w-2 h-2 rounded-full bg-white animate-ping"></span>
                      LIVE
                    </span>
                    <span className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 border border-white/10">
                      <Eye className="w-3.5 h-3.5 text-red-400" />
                      {stream.viewerCount.toLocaleString()} Viewers
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pointer-events-auto">
                    <button
                      onClick={() => setShowAiCaptions(!showAiCaptions)}
                      className={`px-2.5 py-1.5 rounded-full text-[11px] font-bold backdrop-blur-md flex items-center gap-1 border transition-all ${
                        showAiCaptions ? 'bg-purple-600 text-white border-purple-400' : 'bg-black/60 text-slate-300 border-white/20 hover:text-white'
                      }`}
                      title="AI Auto Captions"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-purple-300" />
                      <span>{showAiCaptions ? 'CC ON' : 'CC OFF'}</span>
                    </button>
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/80"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <button className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/80">
                      <Maximize className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* AI Captions Overlay */}
                {showAiCaptions && (
                  <div className="absolute bottom-14 left-6 right-6 text-center pointer-events-none animate-in fade-in">
                    <span className="px-4 py-1.5 rounded-xl bg-black/80 backdrop-blur-md border border-purple-500/50 text-purple-200 font-semibold text-xs inline-block shadow-lg">
                      [AI Live Captions] "Thank you everyone for joining HFArt Live! We are broadcasting high fidelity audio."
                    </span>
                  </div>
                )}

                {/* Bottom Overlay Controls */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                  <div className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md text-slate-200 text-xs font-medium border border-white/10">
                    Category: {stream.category}
                  </div>

                  <button
                    onClick={() => setIsAdBreakModalOpen(true)}
                    className="pointer-events-auto px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-slate-950 font-bold text-xs shadow-lg flex items-center gap-1.5 transition-transform hover:scale-105"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Break/Ads (HV100)</span>
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Quick Reactions Emoji Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-2 overflow-x-auto">
            <span className="text-xs text-slate-400 font-bold whitespace-nowrap pl-2">😊 Quick Reactions:</span>
            <div className="flex items-center gap-2">
              {['❤️', '🔥', '👏', '🎉', '💎', '🇿🇦', '👑'].map((emoji, idx) => (
                <button
                  key={idx}
                  onClick={() => handleReaction(emoji)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-base transition-transform active:scale-125"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Stream Information & Creator Actions Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
            
            {/* Title & Stats */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h1 className="text-base sm:text-lg font-bold text-white">{stream.title}</h1>
                <p className="text-xs text-slate-400 mt-0.5">{stream.description}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* ❤️ Like Button */}
                <button
                  onClick={() => handleReaction('❤️')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 font-bold text-xs border border-rose-800/80 transition-transform active:scale-90"
                >
                  <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                  <span>{likes.toLocaleString()}</span>
                </button>

                {/* 🎁 Gifts Button */}
                <button
                  onClick={() => setIsGiftModalOpen(true)}
                  className="flex items-center gap-1 px-3.5 py-2 rounded-full bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 font-bold text-xs border border-amber-800/80 transition-transform active:scale-95"
                >
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span>Send Gift</span>
                </button>

                {/* 💰 Donate Button */}
                <button
                  onClick={() => setIsDonateModalOpen(true)}
                  className="flex items-center gap-1 px-3.5 py-2 rounded-full bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 font-bold text-xs border border-emerald-800/80 transition-transform active:scale-95"
                >
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                  <span>Donate</span>
                </button>

                {/* 📤 Share Button */}
                <button
                  onClick={() => {
                    setShowShareToast(true);
                    setTimeout(() => setShowShareToast(false), 2500);
                  }}
                  className="p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                  title="Share Stream"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Creator Profile Row */}
            <div className="flex items-center justify-between flex-wrap gap-4">
              
              <div 
                onClick={() => onSelectCreator(creator.id)}
                className="flex items-center gap-3 cursor-pointer group"
              >
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-11 h-11 rounded-full object-cover ring-2 ring-red-500 group-hover:scale-105 transition-transform"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-bold text-white group-hover:text-red-400">{creator.name}</h3>
                    {creator.verified && <span className="text-amber-400 text-xs">✓</span>}
                  </div>
                  <p className="text-xs text-slate-400">
                    {creator.followersCount.toLocaleString()} followers
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Follow Button */}
                <button
                  onClick={() => onToggleFollow(creator.id)}
                  className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                    creator.isFollowing
                      ? 'bg-slate-800 text-slate-300 border border-slate-700'
                      : 'bg-red-600 hover:bg-red-500 text-white shadow-md'
                  }`}
                >
                  {creator.isFollowing ? 'Following' : '+ Follow'}
                </button>

                {/* ⭐ Subscribe Button */}
                <button
                  onClick={() => onToggleSubscribe(creator.id)}
                  className={`px-4 py-2 rounded-full text-xs font-bold border transition-all ${
                    creator.isSubscribed
                      ? 'bg-amber-950/80 text-amber-300 border-amber-600'
                      : 'bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 border-amber-400 hover:from-amber-400 hover:to-rose-400 shadow-md'
                  }`}
                >
                  {creator.isSubscribed ? 'Subscribed ★' : '⭐ Subscribe $4.99'}
                </button>
              </div>

            </div>

            {/* Share Toast */}
            {showShareToast && (
              <div className="p-2.5 rounded-xl bg-emerald-950/80 text-emerald-300 border border-emerald-800 text-xs text-center animate-in fade-in flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Stream URL copied! Share on WhatsApp, Twitter & Facebook!
              </div>
            )}

          </div>

        </div>

        {/* Right Column: Live Chat & Moderator Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl flex flex-col h-[560px] shadow-xl overflow-hidden relative">
          
          {/* Chat Header & Mod Toggle */}
          <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-red-500" />
              <h3 className="text-xs font-bold text-white">Live Chat</h3>
            </div>
            
            <button
              onClick={() => setShowModPanel(!showModPanel)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors ${
                showModPanel ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Shield className="w-3 h-3" />
              Moderation Tools
            </button>
          </div>

          {/* Moderator Bar Settings */}
          {showModPanel && (
            <div className="p-3 bg-slate-950 border-b border-slate-800 space-y-2 text-xs animate-in slide-in-from-top-2">
              <div className="text-[10px] font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1">
                <Shield className="w-3 h-3" /> Moderator & Creator Controls
              </div>
              <div className="flex flex-wrap gap-2 text-[10px]">
                <button
                  onClick={() => setIsSlowMode(!isSlowMode)}
                  className={`px-2.5 py-1 rounded font-semibold border ${
                    isSlowMode ? 'bg-amber-950 text-amber-300 border-amber-600' : 'bg-slate-900 text-slate-400 border-slate-800'
                  }`}
                >
                  {isSlowMode ? 'Slow Mode (5s): ON' : 'Slow Mode: OFF'}
                </button>
                <button
                  onClick={() => setIsFollowersOnly(!isFollowersOnly)}
                  className={`px-2.5 py-1 rounded font-semibold border ${
                    isFollowersOnly ? 'bg-blue-950 text-blue-300 border-blue-600' : 'bg-slate-900 text-slate-400 border-slate-800'
                  }`}
                >
                  {isFollowersOnly ? 'Followers-Only: ON' : 'Followers-Only: OFF'}
                </button>
                <button
                  onClick={() => setIsSubscribersOnly(!isSubscribersOnly)}
                  className={`px-2.5 py-1 rounded font-semibold border ${
                    isSubscribersOnly ? 'bg-purple-950 text-purple-300 border-purple-600' : 'bg-slate-900 text-slate-400 border-slate-800'
                  }`}
                >
                  {isSubscribersOnly ? 'Subs-Only: ON' : 'Subs-Only: OFF'}
                </button>
              </div>
            </div>
          )}

          {/* Messages Stream */}
          <div
            ref={chatContainerRef}
            className="flex-1 p-4 overflow-y-auto space-y-3 no-scrollbar"
          >
            {chatMessages.map((msg, idx) => (
              <div key={msg.id ? `${msg.id}-${idx}` : `msg-${idx}`} className="group relative flex gap-2.5 items-start text-xs p-1.5 rounded-xl hover:bg-slate-800/50 transition-colors">
                <img
                  src={msg.senderAvatar}
                  alt={msg.senderName}
                  className="w-6 h-6 rounded-full object-cover shrink-0 mt-0.5"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-slate-300 hover:text-white cursor-pointer">
                      {msg.senderName}
                    </span>
                    {msg.isBadge && (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 bg-red-950 text-red-400 rounded border border-red-800/80">
                        {msg.isBadge}
                      </span>
                    )}
                    <span className="text-[10px] text-slate-500 ml-auto">{msg.timestamp}</span>
                  </div>
                  
                  <p className={`mt-0.5 leading-snug break-words ${msg.isGift ? 'text-amber-300 font-bold' : 'text-slate-200'}`}>
                    {msg.message}
                  </p>
                </div>

                {/* Mod Action Buttons on hover */}
                {showModPanel && (
                  <div className="absolute right-2 top-1.5 opacity-0 group-hover:opacity-100 flex items-center gap-1 bg-slate-900/90 border border-slate-700 p-1 rounded-lg">
                    <button
                      onClick={() => handleDeleteMessage(msg.id)}
                      className="p-1 hover:text-red-400 text-slate-400"
                      title="Delete message"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleMuteUser(msg.senderName)}
                      className="p-1 hover:text-amber-400 text-slate-400"
                      title="Mute user"
                    >
                      <MicOff className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Chat Input Form */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsGiftModalOpen(true)}
              className="p-2 rounded-xl bg-amber-950/60 text-amber-400 hover:bg-amber-900/80 border border-amber-800/60"
              title="Send Gift"
            >
              <Gift className="w-4 h-4" />
            </button>

            <input
              type="text"
              placeholder="Send a message..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 bg-slate-800/90 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-red-500"
            />

            <button
              type="submit"
              className="p-2 rounded-xl bg-red-600 hover:bg-red-500 text-white shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>

      </div>

      {/* Gifts Modal */}
      {isGiftModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 text-center shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Gift className="w-4 h-4 text-amber-400" />
                Send Virtual Gift
              </h3>
              <span className="text-xs font-mono text-amber-400 font-bold bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                💎 {userSparkles} Sparkles
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {AVAILABLE_GIFTS.map((g) => (
                <button
                  key={g.id}
                  onClick={() => handleSendGift(g)}
                  className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-2xl flex flex-col items-center gap-1.5 transition-all group"
                >
                  <span className="text-3xl group-hover:scale-110 transition-transform">{g.icon}</span>
                  <span className="text-xs font-bold text-white">{g.name}</span>
                  <span className="text-[10px] text-amber-400 font-mono">💎 {g.costSparkles}</span>
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsGiftModalOpen(false)}
              className="w-full py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Donate Modal */}
      {isDonateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                Donate to {creator.name}
              </h3>
              <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 font-bold">
                Direct Creator Support
              </span>
            </div>

            <div className="space-y-3">
              <label className="text-slate-300 font-medium block">Choose Donation Amount</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 25, 50].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setDonateAmount(amt)}
                    className={`py-2 rounded-xl font-bold transition-all ${
                      donateAmount === amt ? 'bg-emerald-500 text-slate-950 shadow-md' : 'bg-slate-950 text-slate-300 border border-slate-800 hover:text-white'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>

              <div className="space-y-1 pt-1">
                <label className="text-slate-400 text-[10px] block">Or enter custom amount ($ USD)</label>
                <input
                  type="number"
                  min="1"
                  value={donateAmount}
                  onChange={(e) => setDonateAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium block">Attached Message (Appears in Chat)</label>
                <textarea
                  value={donateMessage}
                  onChange={(e) => setDonateMessage(e.target.value)}
                  placeholder="Say something nice to the creator..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 h-20 resize-none"
                />
              </div>

              <button
                onClick={handleConfirmDonation}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-950/50 transition-transform active:scale-95"
              >
                Confirm Donation (${donateAmount}.00 USD)
              </button>

              <button
                onClick={() => setIsDonateModalOpen(false)}
                className="w-full py-2 bg-slate-800 text-slate-400 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Ad Break Modal */}
      <AdBreakModal
        isOpen={isAdBreakModalOpen}
        onClose={() => setIsAdBreakModalOpen(false)}
        onStartBreak={handleStartBreak}
      />

    </div>
  );
};
