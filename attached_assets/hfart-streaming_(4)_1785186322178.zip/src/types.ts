export type CategoryType = 
  | 'Live Now' 
  | 'Recommended For You'
  | 'Trending in South Africa'
  | 'Music' 
  | 'Gaming' 
  | 'Sports' 
  | 'Podcasts' 
  | 'News' 
  | 'Entertainment'
  | 'New Creators'
  | 'Trending';

export interface Creator {
  id: string;
  name: string;
  username: string;
  avatar: string;
  banner: string;
  verified: boolean;
  isLive: boolean;
  followersCount: number;
  followingCount: number;
  totalLikes: number;
  totalViews: number;
  bio: string;
  country?: string;
  isFollowing?: boolean;
  isSubscribed?: boolean;
}

export interface AdBreakState {
  isScheduled: boolean;
  startsInSeconds: number; // countdown to break start
  breakDurationSeconds: number; // duration of ad break
  isBreakActive: boolean; // currently playing ad
  currentAdIndex: number;
}

export interface Stream {
  id: string;
  title: string;
  description: string;
  category: CategoryType;
  creator: Creator;
  thumbnail: string;
  viewerCount: number;
  likesCount: number;
  startedAt: string;
  isLive: boolean;
  tags: string[];
  streamUrl?: string; // fallback or placeholder video
  visibility: 'Public' | 'Followers' | 'Subscribers';
  allowClips: boolean;
  enableChat: boolean;
  recordStream: boolean;
  adBreak?: AdBreakState;
}

export interface ChatMessage {
  id: string;
  senderName: string;
  senderAvatar: string;
  message: string;
  timestamp: string;
  isBadge?: string; // e.g. "SUB 6 MO", "MOD", "VIP"
  isGift?: boolean;
  giftType?: string;
  isMuted?: boolean;
}

export interface Clip {
  id: string;
  title: string;
  creatorName: string;
  creatorAvatar: string;
  thumbnail: string;
  duration: string;
  views: number;
  createdAt: string;
}

export interface Recording {
  id: string;
  title: string;
  category: CategoryType;
  thumbnail: string;
  duration: string;
  views: number;
  date: string;
}

export interface CommunityPost {
  id: string;
  creatorName: string;
  creatorAvatar: string;
  content: string;
  image?: string;
  likes: number;
  commentsCount: number;
  timeAgo: string;
}

export interface AdCampaign {
  id: string;
  advertiserName: string;
  title: string;
  videoUrl: string;
  durationSeconds: number;
  cpm: number;
  impressions: number;
  status: 'Active' | 'Paused' | 'Scheduled';
  bannerImage: string;
}

export interface CreatorAnalytics {
  totalViews: number;
  peakConcurrentViewers: number;
  totalWatchTimeHours: number;
  avgWatchTimeMinutes: number;
  adRevenueHV100: number;
  subscriberRevenueUsd: number;
  followerGrowth: number;
  sharesCount: number;
  likesCount: number;
  chatMessagesCount: number;
}

export interface UserNotification {
  id: string;
  type: 'live' | 'follower' | 'reply' | 'reminder' | 'subscription' | 'announcement';
  title: string;
  message: string;
  timeAgo: string;
  read: boolean;
  avatar?: string;
  linkAction?: string;
}

export type NotificationItem = UserNotification;

export interface UserProfile {
  id: string;
  fullName: string;
  username: string;
  email: string;
  country?: string;
  dateOfBirth?: string;
  avatar: string;
  bio?: string;
  followersCount?: number;
  followingCount?: number;
  sparklesBalance?: number;
  isCreator?: boolean;
  verified?: boolean;
  isGuest?: boolean;
  agreedToTerms?: boolean;
  agreedToGuidelines?: boolean;
}

export interface VirtualGift {
  id: string;
  name: string;
  icon: string;
  costSparkles: number;
  color: string;
}

export type ViewMode = 
  | 'home' 
  | 'discover' 
  | 'live_watch' 
  | 'profile' 
  | 'creator_studio' 
  | 'go_live_setup' 
  | 'while_live_creator' 
  | 'admin_dashboard'
  | 'business_center'
  | 'developer_portal';
